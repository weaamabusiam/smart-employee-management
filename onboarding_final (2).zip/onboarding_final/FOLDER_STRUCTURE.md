# Mobile App (React Native)
All React Native code is now in this folder. To run:
- cd mobile
- npm install
- npx react-native run-android (or run-ios)

# Dashboard (React.js)
All React.js dashboard code is now in this folder. To run:
- cd dashboard
- npm install
- npm start (or npx vite)

# Backend (Node.js)
All Node.js backend code is in backend/src. To run:
- cd backend/src
- npm install (in backend root)
- node server.js

# ESP32
All ESP32 code is in esp32/.

# Tests
All backend unit tests are in tests/.

# UML
All UML diagrams are in uml/.

# Database
schema.sql is at the root.

# See README.md for full instructions.

