# Employee Attendance System

This project is a full-stack employee attendance system using Bluetooth technology. It includes:
- ESP32 attendance detection module (C++)
- Mobile app (React Native)
- Central server (Node.js + MySQL)
- Manager dashboard (React.js)
- UML diagrams
- Unit tests (Jest)
- Security best practices

---

## 1. ESP32 Attendance Detection Module
- Location: `esp32/`
- Files: `main.cpp`, `config.h`
- Function: Scans for BLE devices, sends attendance data to server.
- Build: Use PlatformIO or Arduino IDE.

## 2. Mobile Application (React Native)
- Location: `src/`
- Files: `App.js`, `screens/`, `components/`, `services/`
- Function: BLE scan, login, show attendance status/history.
- Run: `npx react-native run-android` or `npx react-native run-ios`

## 3. Central Server (Node.js)
- Main file: `index.js`
- Function: Receives attendance, manages users/employees, JWT login, MySQL storage.
- Run: `node index.js`
- Env: Configure `.env` with DB and JWT_SECRET

## 4. Manager Web Dashboard (React.js)
- Location: `src/dashboard/`
- Function: View/manage employees, attendance, users.
- Run: `npm start` (if using Create React App or Vite)

## 5. Database (MySQL)
- Schema: `schema.sql`
- Import: Use MySQL Workbench or CLI to import.

---

## UML Diagrams
- `uml_use_case.puml`: Use Case
- `uml_sequence.puml`: Sequence
- `uml_dfd.puml`: Data Flow Diagram
- Render with [PlantUML](https://plantuml.com/)

---

## Unit Tests
- Location: `tests/`
- Run: `npm test` (after installing Jest and supertest)

---

## Security Best Practices
- SQL Injection: All queries use prepared statements
- XSS: Sanitize input/output on frontend (e.g., DOMPurify)
- CSRF: Use JWT for API auth or add `csurf` for session-based auth
- Brute Force: Rate limiting enabled on backend
- Passwords: Hashed with bcrypt
- CORS: Enabled for frontend-backend communication
- HTTPS: Use HTTPS in production

---

## Setup Instructions

### 1. Database
- Create a MySQL database and import `schema.sql`.
- Update `.env` with your DB credentials.

### 2. Backend
- Install dependencies: `npm install`
- Start server: `node index.js`

### 3. Mobile App
- Install dependencies: `npm install` in `src/` if needed
- Run on device/emulator: `npx react-native run-android` or `npx react-native run-ios`

### 4. Dashboard
- Install dependencies: `npm install` in `src/dashboard/` if needed
- Start: `npm start` or `npx vite`

### 5. ESP32
- Open `esp32/` in PlatformIO or Arduino IDE
- Update `config.h` with your WiFi and server details
- Upload to ESP32

---

## Notes
- For JWT, set `JWT_SECRET` in `.env`.
- Protect sensitive endpoints with JWT middleware (see comments in `index.js`).
- For production, use HTTPS and secure storage for all secrets.

---

For any issues, check code comments and security notes in each module.

