// This file initializes the Express app and applies middleware.
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { errorHandler } = require('./middleware/errorHandler');

const app = express();

app.use(express.json());
app.use(cors());
app.use(rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: 'Too many requests, please try again later.'
}));

// Routers
app.use('/employees', require('./routes/employees'));
app.use('/attendance', require('./routes/attendance'));
app.use('/users', require('./routes/users'));
app.use('/login', require('./routes/auth'));

// Error handler
app.use(errorHandler);

module.exports = app;

