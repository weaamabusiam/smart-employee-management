// Attendance Controller
const attendanceService = require('../services/attendanceService');

exports.getAllAttendance = async (req, res) => {
  try {
    const { employee_id } = req.query;
    const logs = await attendanceService.getAllAttendance(employee_id);
    res.json(logs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.logAttendance = async (req, res) => {
  try {
    const { employee_id, status, source } = req.body;
    if (!employee_id || !status) {
      return res.status(400).json({ error: 'employee_id and status are required' });
    }
    const result = await attendanceService.logAttendance(employee_id, status, source);
    res.status(201).json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

