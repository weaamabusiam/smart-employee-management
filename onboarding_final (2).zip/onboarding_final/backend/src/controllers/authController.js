// Auth Controller
const authService = require('../services/authService');

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }
    const token = await authService.login(username, password);
    if (!token) return res.status(401).json({ error: 'Invalid credentials' });
    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

