// User Controller
const userService = require('../services/userService');

exports.getAllUsers = async (req, res) => {
  try {
    const users = await userService.getAllUsers();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createUser = async (req, res) => {
  try {
    const { username, password, role_id } = req.body;
    if (!username || !password || !role_id) {
      return res.status(400).json({ error: 'username, password, and role_id are required' });
    }
    const user = await userService.createUser(username, password, role_id);
    res.status(201).json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { username, password, role_id } = req.body;
    const userId = req.params.id;
    if (!userId) return res.status(400).json({ error: 'user id required' });
    const user = await userService.updateUser(userId, username, password, role_id);
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

