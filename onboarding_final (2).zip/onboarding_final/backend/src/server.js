// Start the backend server
const app = require('./app');

const PORT =3003;

app.listen(PORT, () => {
  console.log(`Backend server running on port ${PORT}`);
});

