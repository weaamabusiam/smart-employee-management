// Attendance Service
const db = require('../config/db');

exports.getAllAttendance = (employee_id) => {
  return new Promise((resolve, reject) => {
    let query = 'SELECT * FROM attendance_logs';
    let params = [];
    if (employee_id) {
      query += ' WHERE employee_id = ?';
      params.push(employee_id);
    }
    db.query(query, params, (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
};

exports.logAttendance = (employee_id, status, source) => {
  return new Promise((resolve, reject) => {
    db.query(
      'INSERT INTO attendance_logs (employee_id, status, source) VALUES (?, ?, ?)',
      [employee_id, status, source || 'unknown'],
      (err, result) => {
        if (err) return reject(err);
        resolve({ id: result.insertId, employee_id, status, source });
      }
    );
  });
};

