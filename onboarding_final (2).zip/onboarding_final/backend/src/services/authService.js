// Auth Service
const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.login = (username, password) => {
  return new Promise((resolve, reject) => {
    db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
      if (err) return reject(err);
      if (results.length === 0) return resolve(null);
      const user = results[0];
      bcrypt.compare(password, user.password_hash, (err, match) => {
        if (err) return reject(err);
        if (!match) return resolve(null);
        const token = jwt.sign(
          { id: user.id, username: user.username, role_id: user.role_id },
          process.env.JWT_SECRET || 'dev_secret',
          { expiresIn: '8h' }
        );
        resolve(token);
      });
    });
  });
};

