// Employee Service
const db = require('../config/db');

exports.getAllEmployees = () => {
  return new Promise((resolve, reject) => {
    db.query('SELECT * FROM employees', (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
};

exports.addEmployee = (name, email, phone) => {
  return new Promise((resolve, reject) => {
    db.query('INSERT INTO employees (name, email, phone) VALUES (?, ?, ?)', [name, email, phone], (err, result) => {
      if (err) return reject(err);
      resolve({ id: result.insertId, name, email, phone });
    });
  });
};

