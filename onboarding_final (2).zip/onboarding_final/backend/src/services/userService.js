// User Service
const db = require('../config/db');
const bcrypt = require('bcryptjs');

exports.getAllUsers = () => {
  return new Promise((resolve, reject) => {
    db.query('SELECT id, username, role_id FROM users', (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
};

exports.createUser = (username, password, role_id) => {
  return new Promise((resolve, reject) => {
    bcrypt.hash(password, 10, (err, hash) => {
      if (err) return reject(err);
      const query = 'INSERT INTO users (username, password_hash, role_id) VALUES (?, ?, ?)';
      const params = [username, hash, role_id];
      console.log('Attempting to add user with query:', query);
      console.log('Parameters:', params);
      db.query(query, params, (err, result) => {
        if (err) {
          console.error('DB Error:', err);
          return reject(err);
        }
        console.log('DB Insert Result:', result);
        resolve({ id: result.insertId, username, role_id });
      });
    });
  });
};

exports.updateUser = (userId, username, password, role_id) => {
  return new Promise((resolve, reject) => {
    let fields = [];
    let values = [];
    if (username) { fields.push('username = ?'); values.push(username); }
    if (role_id) { fields.push('role_id = ?'); values.push(role_id); }
    if (password) {
      bcrypt.hash(password, 10, (err, hash) => {
        if (err) return reject(err);
        fields.push('password_hash = ?');
        values.push(hash);
        values.push(userId);
        db.query(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`, values, (err, result) => {
          if (err) return reject(err);
          resolve({ message: 'User updated' });
        });
      });
      return;
    }
    values.push(userId);
    db.query(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`, values, (err, result) => {
      if (err) return reject(err);
      resolve({ message: 'User updated' });
    });
  });
};
