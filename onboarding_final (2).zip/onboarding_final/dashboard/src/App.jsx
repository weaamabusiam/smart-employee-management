import React from 'react';
import EmployeeTable from './components/EmployeeTable';
import AttendanceReport from './components/AttendanceReport';
import UserManagement from './components/UserManagement';

export default function App() {
  return (
    <div style={{ padding: 32 }}>
      <h1>Manager Dashboard</h1>
      <EmployeeTable />
      <AttendanceReport />
      <UserManagement />
    </div>
  );
}

