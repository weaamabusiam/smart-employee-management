import React, { useEffect, useState } from 'react';
import { getAttendance } from '../services/api';

export default function AttendanceReport() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    getAttendance().then(setLogs);
  }, []);

  return (
    <div style={{ marginTop: 32 }}>
      <h2>Attendance Report</h2>
      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>ID</th>
            <th>Employee ID</th>
            <th>Status</th>
            <th>Timestamp</th>
            <th>Source</th>
          </tr>
        </thead>
        <tbody>
          {logs.map(log => (
            <tr key={log.id}>
              <td>{log.id}</td>
              <td>{log.employee_id}</td>
              <td>{log.status}</td>
              <td>{log.timestamp}</td>
              <td>{log.source}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
