import React, { useEffect, useState } from 'react';
import { getUsers, createUser } from '../services/api';

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ username: '', password: '', role_id: '' });

  useEffect(() => {
    getUsers().then(setUsers);
  }, []);

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    await createUser(form);
    setUsers(await getUsers());
    setForm({ username: '', password: '', role_id: '' });
  };

  return (
    <div style={{ marginTop: 32 }}>
      <h2>User Management</h2>
      <form onSubmit={handleSubmit} style={{ marginBottom: 16 }}>
        <input name="username" placeholder="Username" value={form.username} onChange={handleChange} required />
        <input name="password" type="password" placeholder="Password" value={form.password} onChange={handleChange} required />
        <input name="role_id" placeholder="Role ID" value={form.role_id} onChange={handleChange} required />
        <button type="submit">Add User</button>
      </form>
      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Role ID</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.username}</td>
              <td>{user.role_id}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

