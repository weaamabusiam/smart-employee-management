import axios from 'axios';

const API_URL = 'http://localhost:3003'; // Update if your backend runs elsewhere

export const getEmployees = async () => {
  const res = await axios.get(`${API_URL}/employees`);
  return res.data;
};

export const getAttendance = async () => {
  const res = await axios.get(`${API_URL}/attendance`);
  return res.data;
};

export const getUsers = async () => {
  const res = await axios.get(`${API_URL}/users`);
  return res.data;
};

export const createUser = async (data) => {
  const res = await axios.post(`${API_URL}/users`, data);
  return res.data;
};

