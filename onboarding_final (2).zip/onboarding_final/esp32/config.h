#ifndef CONFIG_H
#define CONFIG_H

#define WIFI_SSID "your_wifi_ssid"
#define WIFI_PASSWORD "your_wifi_password"
#define SERVER_URL "http://your-server-ip:3000/attendance"
#define EMPLOYEE_MAC "AA:BB:CC:DD:EE:FF" // Example MAC address
#define EMPLOYEE_ID "1"

#endif // CONFIG_H

