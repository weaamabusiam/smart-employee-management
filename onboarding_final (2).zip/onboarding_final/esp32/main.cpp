#include <WiFi.h>
#include <HTTPClient.h>
#include <BLEDevice.h>
#include "config.h"

void sendAttendance(const char* employeeId, const char* status) {
    if (WiFi.status() == WL_CONNECTED) {
        HTTPClient http;
        http.begin(SERVER_URL);
        http.addHeader("Content-Type", "application/json");
        String payload = String("{\"employee_id\":") + employeeId + ",\"status\":\"" + status + "\",\"source\":\"esp32\"}";
        int httpResponseCode = http.POST(payload);
        http.end();
    }
}

class MyAdvertisedDeviceCallbacks: public BLEAdvertisedDeviceCallbacks {
    void onResult(BLEAdvertisedDevice advertisedDevice) {
        if (String(advertisedDevice.getAddress().toString().c_str()) == EMPLOYEE_MAC) {
            sendAttendance(EMPLOYEE_ID, "present");
        }
    }
};

void setup() {
    Serial.begin(115200);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println("WiFi connected");

    BLEDevice::init("");
    BLEScan* pBLEScan = BLEDevice::getScan();
    pBLEScan->setAdvertisedDeviceCallbacks(new MyAdvertisedDeviceCallbacks());
    pBLEScan->setActiveScan(true);
    pBLEScan->start(5, false);
}

void loop() {
    delay(10000); // BLE scan runs in background
}

