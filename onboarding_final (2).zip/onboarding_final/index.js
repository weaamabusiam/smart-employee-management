require('dotenv').config();
const mysql = require('mysql2');
const express = require('express');
const rateLimit = require('express-rate-limit');
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 3000;

// Update these values with your actual database credentials
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port : process.env.DB_PORT || 3306 // Default MySQL port
});

db.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to MySQL database.');
});

app.use(express.json());
app.use(cors()); // Enable CORS for all routes

// Rate limiter to prevent brute force attacks
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: 'Too many requests, please try again later.'
});
app.use(limiter);

// Example: Get all employees
app.get('/employees', (req, res) => {
    db.query('SELECT * FROM employees', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// Example: Add a new employee
app.post('/employees', (req, res) => {
    const { name, email, phone } = req.body;
    db.query('INSERT INTO employees (name, email, phone) VALUES (?, ?, ?)', [name, email, phone], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ id: result.insertId, name, email, phone });
    });
});

// --- Attendance Logging Endpoint ---
// ESP32 or mobile app posts attendance logs
app.post('/attendance',
    body('employee_id').isInt(),
    body('status').isIn(['present', 'absent', 'late']),
    (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        const { employee_id, status, source } = req.body;
        // Use prepared statements to prevent SQL injection
        db.query(
            'INSERT INTO attendance_logs (employee_id, status, source) VALUES (?, ?, ?)',
            [employee_id, status, source || 'unknown'],
            (err, result) => {
                if (err) return res.status(500).json({ error: err.message });
                res.status(201).json({ id: result.insertId, employee_id, status, source });
            }
        );
    }
);

// --- Get all attendance logs (optionally filter by employee_id) ---
app.get('/attendance', (req, res) => {
    const { employee_id } = req.query;
    let query = 'SELECT * FROM attendance_logs';
    let params = [];
    if (employee_id) {
        query += ' WHERE employee_id = ?';
        params.push(employee_id);
    }
    db.query(query, params, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// --- User Management Endpoints ---
// Create user
app.post('/users',
    body('username').isAlphanumeric().isLength({ min: 3 }),
    body('password').isLength({ min: 6 }),
    body('role_id').isInt(),
    (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        const { username, password, role_id } = req.body;
        // Hash password before storing (use bcrypt)
        bcrypt.hash(password, 10, (err, hash) => {
            if (err) return res.status(500).json({ error: err.message });
            db.query(
                'INSERT INTO users (username, password_hash, role_id) VALUES (?, ?, ?)',
                [username, hash, role_id],
                (err, result) => {
                    if (err) return res.status(500).json({ error: err.message });
                    res.status(201).json({ id: result.insertId, username, role_id });
                }
            );
        });
    }
);

// Update user
app.put('/users/:id',
    body('username').optional().isAlphanumeric().isLength({ min: 3 }),
    body('password').optional().isLength({ min: 6 }),
    body('role_id').optional().isInt(),
    (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        const { username, password, role_id } = req.body;
        const userId = req.params.id;
        let fields = [];
        let values = [];
        if (username) { fields.push('username = ?'); values.push(username); }
        if (role_id) { fields.push('role_id = ?'); values.push(role_id); }
        if (password) {
            bcrypt.hash(password, 10, (err, hash) => {
                if (err) return res.status(500).json({ error: err.message });
                fields.push('password_hash = ?');
                values.push(hash);
                values.push(userId);
                db.query(
                    `UPDATE users SET ${fields.join(', ')} WHERE id = ?`,
                    values,
                    (err, result) => {
                        if (err) return res.status(500).json({ error: err.message });
                        res.json({ message: 'User updated' });
                    }
                );
            });
            return;
        }
        values.push(userId);
        db.query(
            `UPDATE users SET ${fields.join(', ')} WHERE id = ?`,
            values,
            (err, result) => {
                if (err) return res.status(500).json({ error: err.message });
                res.json({ message: 'User updated' });
            }
        );
    }
);

// --- Get all users ---
app.get('/users', (req, res) => {
    db.query('SELECT id, username, role_id FROM users', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// --- Login Endpoint (returns JWT) ---
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password required' });
    }
    db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(401).json({ error: 'Invalid credentials' });
        const user = results[0];
        bcrypt.compare(password, user.password_hash, (err, match) => {
            if (err) return res.status(500).json({ error: err.message });
            if (!match) return res.status(401).json({ error: 'Invalid credentials' });
            // Create JWT
            const token = jwt.sign({ id: user.id, username: user.username, role_id: user.role_id }, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '8h' });
            res.json({ token });
        });
    });
});

// --- JWT Middleware (protect sensitive endpoints) ---
function authenticateJWT(req, res, next) {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.split(' ')[1];
        jwt.verify(token, process.env.JWT_SECRET || 'dev_secret', (err, user) => {
            if (err) return res.sendStatus(403);
            req.user = user;
            next();
        });
    } else {
        res.sendStatus(401);
    }
}

// Example: Protect user management endpoints (uncomment to enforce)
// app.post('/users', authenticateJWT, ...);
// app.put('/users/:id', authenticateJWT, ...);
// app.get('/users', authenticateJWT, ...);

// --- Security Notes ---
// XSS: Sanitize all user input/output on frontend (e.g., DOMPurify for React)
// CSRF: Use JWT for API auth or add csurf middleware for session-based auth
// CORS: Configured above for cross-origin requests
// SQL Injection: All queries use prepared statements
// Brute Force: Rate limiting is enabled
// Passwords: Always hashed with bcrypt
// HTTPS: Use HTTPS in production for all endpoints

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

console.log('Happy developing ✨')
