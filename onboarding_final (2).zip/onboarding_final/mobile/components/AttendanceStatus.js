import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function AttendanceStatus({ status }) {
  let color = '#888';
  if (status === 'Present') color = 'green';
  else if (status === 'Absent') color = 'red';

  return (
    <View style={[styles.statusContainer, { borderColor: color }]}>
      <Text style={[styles.statusText, { color }]}>{status}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  statusContainer: {
    borderWidth: 2,
    borderRadius: 8,
    padding: 10,
    marginBottom: 20,
  },
  statusText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
});

