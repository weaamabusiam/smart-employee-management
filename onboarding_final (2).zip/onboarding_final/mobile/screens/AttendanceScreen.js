import React, { useEffect, useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { scanForESP32 } from '../services/BluetoothService';
import { fetchAttendance } from '../services/ApiService';
import AttendanceStatus from '../components/AttendanceStatus';

export default function AttendanceScreen() {
  const [status, setStatus] = useState('Unknown');
  const [device, setDevice] = useState(null);
  const [attendance, setAttendance] = useState(null);

  useEffect(() => {
    scanForESP32((foundDevice) => {
      setDevice(foundDevice);
      setStatus('Present');
      // Optionally fetch attendance logs from server
      // fetchAttendance(foundDevice.id).then(setAttendance);
    });
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Attendance Status</Text>
      <AttendanceStatus status={status} />
      {device && <Text>Device: {device.name}</Text>}
      {/* {attendance && <Text>Last attendance: {attendance.timestamp}</Text>} */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
});
