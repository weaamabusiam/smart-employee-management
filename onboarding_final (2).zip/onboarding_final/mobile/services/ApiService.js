import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = 'http://your-server-ip:3000'; // Replace with your backend URL

// Fetch attendance logs for a given employee
export const fetchAttendance = async (employeeId) => {
  const res = await axios.get(`${API_URL}/attendance?employee_id=${employeeId}`);
  return res.data;
};

// Login function to authenticate with backend and store JWT token in AsyncStorage
export const login = async (username, password) => {
  try {
    const res = await axios.post(`${API_URL}/login`, { username, password });
    const token = res.data.token;
    if (!token) throw new Error('No token received');
    await AsyncStorage.setItem('authToken', token);
    return token;
  } catch (err) {
    throw new Error(err.response?.data?.error || 'Login failed');
  }
};
