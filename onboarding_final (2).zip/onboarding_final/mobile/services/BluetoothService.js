import { BleManager } from 'react-native-ble-plx';

const manager = new BleManager();

// Scans for ESP32 devices and calls onDeviceFound when found
export const scanForESP32 = (onDeviceFound) => {
  manager.startDeviceScan(null, null, (error, device) => {
    if (error) return;
    if (device && device.name && device.name.includes('ESP32')) {
      onDeviceFound(device);
      manager.stopDeviceScan();
    }
  });
};

