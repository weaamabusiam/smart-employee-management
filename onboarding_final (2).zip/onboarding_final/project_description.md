I am building an employee attendance system using Bluetooth technology. The system consists of an ESP32 microcontroller, a mobile application, and a central cloud-based server with a MySQL database. The system should automatically detect employees when they enter or leave the workplace — without any manual interaction.

Please help me design the initial architecture and code structure for the following modules:
please help implement the full project
1. **Attendance Detection Module (ESP32):**
    - Language: C/C++
    - Function: Detect nearby mobile devices using Bluetooth LE and send attendance data to the server.

2. **Mobile Application (Android/iOS):**
    - Language: JavaScript (React Native or any suitable framework)
    - Function: Communicate with the ESP32 via Bluetooth and display attendance data to the user.

3. **Central Server:**
    - Language: Node.js
    - Function: Receive attendance data, manage users and roles, store data in a MySQL database.

4. **Manager Web Dashboard:**
    - Language: JavaScript (React.js)
    - Function: View attendance reports, manage employees, control system settings and user permissions.

5. **Database (MySQL):**
    - Suggested tables: `employees`, `attendance_logs`, `users`, `roles`

Also provide:

- **UML diagrams**, including:
    - Use Case diagram (e.g., identifying presence and generating reports)
    - Sequence diagram (e.g., detection and data transmission flow)
    - Data Flow Diagram (DFD) showing the flow from ESP32 to server to dashboard

- **Unit test examples** using Jest for:
    - Attendance module logic (e.g., detecting device in range)
    - User management module (e.g., creating and updating users)

- Include **security best practices** to protect against:
    - SQL Injection (e.g., using prepared statements)
    - XSS (sanitize input/output)
    - CSRF (use tokens)
    - Brute force attacks (e.g., login rate limiting)

Comment your code and add relevant notes and tips.
