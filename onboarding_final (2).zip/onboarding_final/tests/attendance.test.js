const request = require('supertest');
const express = require('express');

// Mock Express app and DB
const app = express();
app.use(express.json());

// Mock DB connection
const db = { query: jest.fn() };

// Inject mock DB into route handler (example only)
app.post('/attendance', (req, res) => {
    const { employee_id, status, source } = req.body;
    if (!employee_id || !['present', 'absent', 'late'].includes(status)) {
        return res.status(400).json({ error: 'Invalid input' });
    }
    db.query('INSERT INTO attendance_logs (employee_id, status, source) VALUES (?, ?, ?)', [employee_id, status, source || 'unknown'], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ id: 1, employee_id, status, source });
    });
});

describe('POST /attendance', () => {
    it('should log attendance with valid data', async () => {
        db.query.mockImplementation((q, vals, cb) => cb(null, { insertId: 1 }));
        const res = await request(app)
            .post('/attendance')
            .send({ employee_id: 1, status: 'present', source: 'esp32' });
        expect(res.statusCode).toBe(201);
        expect(res.body.status).toBe('present');
    });
    it('should reject invalid status', async () => {
        const res = await request(app)
            .post('/attendance')
            .send({ employee_id: 1, status: 'invalid' });
        expect(res.statusCode).toBe(400);
    });
});

