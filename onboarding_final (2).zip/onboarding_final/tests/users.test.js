const request = require('supertest');
const express = require('express');
const bcrypt = require('bcryptjs');

// Mock Express app and DB
const app = express();
app.use(express.json());
const db = { query: jest.fn() };

// Create user endpoint (simplified for test)
app.post('/users', async (req, res) => {
    const { username, password, role_id } = req.body;
    if (!username || !password || !role_id) {
        return res.status(400).json({ error: 'Missing fields' });
    }
    const hash = await bcrypt.hash(password, 10);
    db.query('INSERT INTO users (username, password_hash, role_id) VALUES (?, ?, ?)', [username, hash, role_id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ id: 1, username, role_id });
    });
});

describe('POST /users', () => {
    it('should create a user with valid data', async () => {
        db.query.mockImplementation((q, vals, cb) => cb(null, { insertId: 1 }));
        const res = await request(app)
            .post('/users')
            .send({ username: 'testuser', password: 'password123', role_id: 2 });
        expect(res.statusCode).toBe(201);
        expect(res.body.username).toBe('testuser');
    });
    it('should reject missing fields', async () => {
        const res = await request(app)
            .post('/users')
            .send({ username: 'testuser' });
        expect(res.statusCode).toBe(400);
    });
});

