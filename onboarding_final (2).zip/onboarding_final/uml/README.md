# UML Diagrams

All UML diagrams for the project are stored here:
- uml_use_case.puml
- uml_sequence.puml
- uml_dfd.puml

You can render them using PlantUML or any compatible tool.

