# 🏢 Bluetooth-Based Employee Attendance System

A comprehensive, full-stack employee attendance management system using Bluetooth Low Energy (BLE) technology for automatic presence detection. The system includes hardware detection, mobile applications, a central server, and a modern web dashboard.

## 📚 Documentation Navigation

- **[🔧 ESP32 Hardware](esp32/README.md)** - Hardware setup and BLE scanning
- **[🖥️ Backend Server](backend/README.md)** - API documentation and database
- **[📊 Dashboard](dashboard/README.md)** - Web interface and admin features
- **[📱 Mobile App](mobile/README.md)** - React Native application

## 🎯 System Overview

This project implements an innovative solution for managing employee attendance by leveraging **Bluetooth LE technology** to automatically detect when an employee enters or leaves the workspace, logging their presence without requiring any manual action.

### Core Components
1. **🔧 [ESP32 Hardware Detector](esp32/README.md)** - Scans for employee Bluetooth signals
2. **📱 [Mobile Application](mobile/README.md)** - React Native app for employee interaction
3. **🖥️ [Central Server](backend/README.md)** - Node.js backend with MySQL database
4. **📊 [Manager Dashboard](dashboard/README.md)** - React.js web portal for administration
5. **🗄️ Database** - MySQL with comprehensive schema

## 🏗️ System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   ESP32 Device  │    │   Mobile App    │    │   Web Dashboard │
│   (BLE Scanner) │    │  (React Native) │    │     (React)     │
└─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘
          │                      │                      │
          │         HTTP         │         HTTP         │
          └──────────────────────┼──────────────────────┘
                                 │
                    ┌─────────────▼─────────────┐
                    │     Central Server        │
                    │      (Node.js/Express)    │
                    └─────────────┬─────────────┘
                                  │
                    ┌─────────────▼─────────────┐
                    │      MySQL Database       │
                    │   (Attendance & Users)    │
                    └───────────────────────────┘
```

## ✨ Key Features

### 🔄 Automatic Detection
- **Bluetooth LE Scanning** - ESP32 continuously scans for employee devices
- **Proximity Detection** - Automatic connection when employees are nearby
- **Real-time Logging** - Attendance recorded without manual intervention

### 👥 Employee Management
- **Complete CRUD Operations** - Add, edit, delete employees
- **Department Assignment** - Organize employees by departments
- **Bluetooth Device Pairing** - Link employee devices to profiles
- **Present Status Tracking** - Real-time presence monitoring

### 🏢 Department Management
- **Organizational Structure** - Create and manage departments
- **Employee-Department Assignment** - Assign employees to departments
- **Department Information** - Detailed department descriptions

### 📊 Advanced Reporting
- **Attendance Analytics** - Comprehensive attendance statistics
- **Interactive Charts** - 7-day attendance trends
- **Date Range Filtering** - Flexible reporting periods
- **Real-time Dashboard** - Live attendance monitoring

### 🔐 Security & Authentication
- **JWT Authentication** - Secure token-based authentication
- **Role-based Access Control** - Different permission levels
- **Password Hashing** - bcrypt encryption
- **Rate Limiting** - Protection against brute force attacks

## 🚀 Quick Start

### Prerequisites
- **Node.js** (v16 or higher)
- **MySQL** (v8.0 or higher)
- **PlatformIO** or **Arduino IDE** (for ESP32)
- **React Native CLI** (for mobile app)

### 1. Database Setup
```bash
# Create MySQL database
mysql -u root -p
CREATE DATABASE attendance_system;

# Import schema
mysql -u root -p attendance_system < schema.sql
```

### 2. [Backend Setup](backend/README.md)
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your database credentials
npm start
```

### 3. [Dashboard Setup](dashboard/README.md)
```bash
cd dashboard
npm install
npm run dev
```

### 4. [Mobile App Setup](mobile/README.md)
```bash
cd mobile
npm install
npx react-native run-android  # or run-ios
```

### 5. [ESP32 Setup](esp32/README.md)
```bash
cd esp32
# Open in PlatformIO or Arduino IDE
# Update config.h with your WiFi and server details
# Upload to ESP32
```

## 📁 Project Structure

```
├── [backend/](backend/README.md)                 # Node.js server
│   ├── src/
│   │   ├── controllers/     # API controllers
│   │   ├── services/        # Business logic
│   │   ├── routes/          # API routes
│   │   ├── middleware/      # Auth & validation
│   │   └── config/          # Database config
│   └── package.json
├── [dashboard/](dashboard/README.md)               # React web dashboard
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── services/        # API services
│   │   └── App.jsx
│   └── package.json
├── [mobile/](mobile/README.md)                  # React Native app
│   ├── screens/             # App screens
│   ├── components/          # Reusable components
│   ├── services/            # API & Bluetooth services
│   └── package.json
├── [esp32/](esp32/README.md)                   # ESP32 hardware code
│   ├── main.cpp            # Main Arduino code
│   └── config.h            # Configuration file
├── schema.sql              # Database schema
└── README.md               # This file
```

## 🔧 Configuration

### Environment Setup
This project uses environment variables for configuration. Follow these steps:

1. **Copy the configuration template:**
   ```bash
   cp config.example.js config.js
   ```

2. **Update the configuration file:**
   Edit `config.js` with your specific settings:
   - Database credentials
   - JWT secrets
   - API endpoints
   - Bluetooth settings

3. **Create individual .env files for each component:**
   ```bash
   # Backend
   cp backend/.env.example backend/.env
   
   # Dashboard (if needed)
   cp dashboard/.env.example dashboard/.env
   
   # Mobile (if needed)
   cp mobile/.env.example mobile/.env
   ```

### [Backend Configuration](backend/README.md#configuration)
Create `backend/.env`:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=attendance_system
JWT_SECRET=your_jwt_secret
PORT=3001
CORS_ORIGIN=http://localhost:3000,http://localhost:5173
```

### [ESP32 Configuration](esp32/README.md#configuration)
Update `esp32/config.h`:
```cpp
#define WIFI_SSID "your_wifi_ssid"
#define WIFI_PASSWORD "your_wifi_password"
#define SERVER_URL "http://localhost:3001/api/esp32/scan"
#define EMPLOYEE_MAC "AA:BB:CC:DD:EE:FF"
#define EMPLOYEE_ID "EMP001"
```

## 🌐 Access Points

- **[Dashboard](dashboard/README.md#access-the-dashboard)**: http://localhost:5173 (Login: admin/admin123)
- **[Backend API](backend/README.md#api-endpoints)**: http://localhost:3001/api
- **[Mobile App](mobile/README.md#access-points)**: React Native development build
- **[ESP32](esp32/README.md#access-points)**: Hardware device with BLE scanning

## 🧪 Testing

### Unit Tests
```bash
# [Backend tests](backend/README.md#testing)
cd backend
npm test

# [Dashboard tests](dashboard/README.md#testing)
cd dashboard
npm test
```

### End-to-End Testing
1. **User Onboarding** - Create users via dashboard
2. **Department Management** - Create departments and assign employees
3. **Bluetooth Detection** - Test ESP32 device detection
4. **Attendance Logging** - Verify automatic and manual logging
5. **Real-time Updates** - Check dashboard live updates

## 🔒 Security Features

- **SQL Injection Prevention** - Prepared statements
- **XSS Protection** - Input sanitization
- **CSRF Protection** - JWT tokens
- **Rate Limiting** - Request throttling
- **Password Security** - bcrypt hashing
- **CORS Configuration** - Secure cross-origin requests

## 📊 Database Schema

### Core Tables
- **`departments`** - Organizational departments
- **`employees`** - Employee information with department assignments
- **`attendance_logs`** - Real-time attendance records
- **`users`** - System user accounts
- **`roles`** - User role definitions

### Key Relationships
- Employees belong to departments
- Attendance logs reference employees
- Users have assigned roles
- Foreign key constraints ensure data integrity

## 🚀 Deployment

### Production Checklist
- [ ] Configure production database
- [ ] Set up HTTPS certificates
- [ ] Configure environment variables
- [ ] Set up reverse proxy (nginx)
- [ ] Configure firewall rules
- [ ] Set up monitoring and logging
- [ ] Configure backup strategies

### Docker Deployment
```bash
# Build and run with Docker Compose
docker-compose up -d
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For issues and questions:
1. Check the troubleshooting section in each module's README
2. Review the project documentation
3. Create an issue in the repository

## 🎉 Acknowledgments

- **ESP32** - Hardware platform for Bluetooth scanning
- **React Native** - Cross-platform mobile development
- **Node.js** - Backend server framework
- **React** - Frontend dashboard framework
- **MySQL** - Database management system

---

**Built with ❤️ for modern attendance management**





3. Backend Core Functionality
Add ESP32 communication endpoints
Add real-time attendance processing
Add device authentication
Add WebSocket/SSE support
4. Database Schema
Add detection_events table
Add attendance_sessions table
Add esp32_devices table
Add signal strength tracking
5. Dashboard Real-Time Features
Add live attendance view
Add real-time notifications
Add ESP32 status monitoring
6. Device Authentication
Add ESP32 device registration
Add authentication tokens
Add security validation
7. Entry/Exit Logic
Add signal strength thresholds
Add time-based presence tracking
Add duplicate detection prevention
8. Multi-Location Support
Add multiple detection points
Add location-based attendance
Add ESP32 device management
9. Real-Time Communication
Add WebSocket connections
Add push notifications
Add real-time dashboard updates
10. Offline Handling
Add ESP32 local storage
Add mobile offline viewing
Add data synchronization
Which item would you like to start with? Just tell me the number and what you want me to do, and I'll implement it step by step.