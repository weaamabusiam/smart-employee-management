# 🔧 ESP32 Hardware - Employee Attendance System

An ESP32-based **dumb scanner** that continuously scans for Bluetooth Low Energy (BLE) devices and sends raw detection data to the central server. The ESP32 performs no business logic - it simply collects MAC addresses and signal strength data for the backend to process.

> **📚 [← Back to Main Documentation](../README.md)** | **[🖥️ Backend Server](../backend/README.md)** | **[📊 Dashboard](../dashboard/README.md)** | **[📱 Mobile App](../mobile/README.md)**

## 🚀 Quick Start

### Prerequisites
- ESP32 development board
- PlatformIO IDE or Arduino IDE
- WiFi network access
- Backend server running (port 3000)

### Installation
```bash
# Using PlatformIO
pio project init --board esp32dev
pio lib install

# Using Arduino IDE
# Install ESP32 board package
# Tools > Board > ESP32 Arduino > ESP32 Dev Module
```

### Configuration
1. Update `config.h` with your settings
2. Upload code to ESP32
3. Monitor serial output for status

## 🏗️ Hardware Architecture

### Project Structure
```
esp32/
├── main.cpp              # Main Arduino code
├── config.h              # Configuration file
├── platformio.ini        # PlatformIO configuration
└── README.md
```

### Core Components
- **ESP32 Microcontroller** - Main processing unit
- **WiFi Module** - Network connectivity
- **Bluetooth LE Module** - Device scanning
- **Serial Interface** - Debug communication

## ⚙️ Configuration

### WiFi Settings
```cpp
#define WIFI_SSID "your_wifi_ssid"
#define WIFI_PASSWORD "your_wifi_password"
```

### Server Configuration
```cpp
#define SERVER_URL "http://localhost:3000/api/esp32/scan"
#define ESP32_ID "ESP32_001"  // Unique identifier for this ESP32
```

### BLE Scan Configuration
```cpp
#define SCAN_DURATION_SECONDS 5     // Duration of each active scan
#define SCAN_INTERVAL_MS 100        // Scan interval in milliseconds
#define SCAN_WINDOW_MS 99           // Scan window in milliseconds
#define POST_SCAN_DELAY_SECONDS 25  // Delay before next scan cycle
```

## 🔧 Hardware Setup

### Required Components
- **ESP32 Development Board** - Main microcontroller
- **Power Supply** - 5V/3.3V power source
- **Antenna** - WiFi and Bluetooth antennas
- **Enclosure** - Protective housing (optional)

### Pin Configuration
- **GPIO 2** - Built-in LED (status indicator)
- **GPIO 1, 3** - Serial communication
- **Built-in WiFi** - Network connectivity
- **Built-in Bluetooth** - BLE scanning

### Power Requirements
- **Voltage**: 3.3V - 5V
- **Current**: 80mA (active), 10mA (sleep)
- **Power Source**: USB or external power supply

## 📡 Bluetooth Integration

### BLE Scanning (Dumb Scanner)
The ESP32 continuously scans for **ALL** Bluetooth Low Energy devices and sends raw data:

```cpp
// Initialize BLE for scanning only
BLEDevice::init("");  // No specific device name needed
BLEScan* pBLEScan = BLEDevice::getScan();

// Configure scan parameters
pBLEScan->setActiveScan(true);
pBLEScan->setInterval(SCAN_INTERVAL_MS);
pBLEScan->setWindow(SCAN_WINDOW_MS);

// Start scanning
pBLEScan->start(SCAN_DURATION_SECONDS, false);
```

### Raw Data Collection
The ESP32 collects **ALL** detected devices without filtering:

```cpp
class MyAdvertisedDeviceCallbacks: public BLEAdvertisedDeviceCallbacks {
    std::vector<std::pair<std::string, int>> detectedDevices;
    
    void onResult(BLEAdvertisedDevice advertisedDevice) {
        // Store ALL detected devices (MAC + RSSI)
        detectedDevices.push_back({
            advertisedDevice.getAddress().toString(),
            advertisedDevice.getRSSI()
        });
    }
};
```

### Data Transmission
Raw scan data is sent to the backend for processing:

```cpp
void sendScanData(const std::vector<std::pair<std::string, int>>& devices) {
    DynamicJsonDocument doc(1024);
    doc["esp32_id"] = ESP32_ID;
    JsonArray scans = doc.createNestedArray("scans");
    
    for (const auto& device : devices) {
        JsonObject scan = scans.createNestedObject();
        scan["mac_address"] = device.first;
        scan["rssi"] = device.second;
    }
    
    // Send to backend
    http.POST(payload);
}
```

## 🌐 Network Communication

### WiFi Connection
```cpp
void connectToWiFi() {
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println("WiFi connected!");
}
```

### HTTP Communication
```cpp
void sendScanData(const std::vector<std::pair<std::string, int>>& devices) {
    if (WiFi.status() == WL_CONNECTED) {
        HTTPClient http;
        http.begin(SERVER_URL);
        http.addHeader("Content-Type", "application/json");
        http.addHeader("X-ESP32-ID", ESP32_ID);
        
        DynamicJsonDocument doc(1024);
        doc["esp32_id"] = ESP32_ID;
        JsonArray scans = doc.createNestedArray("scans");
        
        for (const auto& device : devices) {
            JsonObject scan = scans.createNestedObject();
            scan["mac_address"] = device.first;
            scan["rssi"] = device.second;
        }
        
        String payload;
        serializeJson(doc, payload);
        
        int httpResponseCode = http.POST(payload);
        http.end();
    }
}
```

## 🔄 Operation Flow

### Initialization
1. **Serial Setup** - Initialize debug communication
2. **WiFi Connection** - Connect to network
3. **BLE Initialization** - Set up Bluetooth scanning
4. **Server Verification** - Test backend connectivity

### Main Loop
1. **BLE Scanning** - Scan for ALL Bluetooth devices
2. **Data Collection** - Collect MAC addresses and RSSI values
3. **Raw Data Transmission** - Send all detected devices to server
4. **Wait Cycle** - Wait before next scan (30-second total cycle)
5. **Error Handling** - Handle connection errors

### Error Handling
- **WiFi Reconnection** - Automatic reconnection
- **Server Retry** - Retry failed requests
- **BLE Recovery** - Restart scanning on errors
- **Status Logging** - Serial debug output

## 🛠️ Development

### PlatformIO Setup
```ini
[env:esp32dev]
platform = espressif32
board = esp32dev
framework = arduino
monitor_speed = 115200
lib_deps = 
    espressif32/ESP32 BLE Arduino@^1.0.1
```

### Arduino IDE Setup
1. Install ESP32 board package
2. Select board: ESP32 Dev Module
3. Set upload speed: 115200
4. Enable serial monitor

### Debugging
```cpp
// Enable debug output
Serial.begin(115200);

// Debug messages
Serial.println("Starting ESP32 Attendance System...");
Serial.print("WiFi Status: ");
Serial.println(WiFi.status());
Serial.print("BLE Status: ");
Serial.println(BLEDevice::getInitialized());
```

## 📊 Monitoring & Status

### Serial Output
The ESP32 provides detailed status information:

```
Starting ESP32 Attendance System...
Connecting to WiFi
WiFi connected!
IP address: 192.168.1.100
BLE initialized. Starting scan for employee devices...
Detected employee device: AA:BB:CC:DD:EE:FF
HTTP Response Code: 200
Response: {"success": true, "message": "Attendance logged"}
```

### Status Indicators
- **Built-in LED** - WiFi connection status
- **Serial Output** - Detailed debug information
- **HTTP Responses** - Server communication status
- **BLE Status** - Bluetooth scanning status

## 🔧 Troubleshooting

### Common Issues

#### WiFi Connection Problems
```cpp
// Check WiFi status
if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi connection failed");
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}
```

#### BLE Scanning Issues
```cpp
// Restart BLE scanning
BLEScan* pBLEScan = BLEDevice::getScan();
pBLEScan->start(SCAN_DURATION, false);
```

#### Server Communication Errors
```cpp
// Check server response
if (httpResponseCode > 0) {
    Serial.println("HTTP Response Code: " + String(httpResponseCode));
} else {
    Serial.println("Error on HTTP request");
}
```

### Debug Commands
```cpp
// Check WiFi status
Serial.println("WiFi Status: " + String(WiFi.status()));

// Check BLE status
Serial.println("BLE Initialized: " + String(BLEDevice::getInitialized()));

// Check server connectivity
HTTPClient http;
http.begin("http://localhost:3000/api/health");
int response = http.GET();
Serial.println("Server Response: " + String(response));
```

## 🚀 Deployment

### Hardware Deployment
1. **Configuration** - Update config.h with production settings
2. **Upload Code** - Flash firmware to ESP32
3. **Power On** - Connect to power source
4. **Verification** - Check serial output for status
5. **Positioning** - Place in optimal location

### Production Settings
```cpp
// Production configuration
#define WIFI_SSID "PRODUCTION_WIFI"
#define WIFI_PASSWORD "SECURE_PASSWORD"
#define SERVER_URL "https://your-domain.com/api/attendance"
#define SCAN_DURATION 10
#define SCAN_INTERVAL 30
```

### Monitoring
- **Serial Monitor** - Real-time status monitoring
- **Network Monitoring** - WiFi connection status
- **Server Logs** - Backend attendance logs
- **Power Monitoring** - Power consumption tracking

## 📈 Performance Optimization

### Scanning Optimization
- **Scan Duration** - Optimize scan intervals
- **Active Scanning** - Use active scanning for better detection
- **Filtering** - Filter devices by MAC address
- **Power Management** - Optimize power consumption

### Network Optimization
- **Connection Pooling** - Reuse HTTP connections
- **Timeout Settings** - Optimize request timeouts
- **Retry Logic** - Implement smart retry mechanisms
- **Error Recovery** - Automatic error recovery

## 🔐 Security Considerations

### Network Security
- **WiFi Security** - Use WPA2/WPA3 encryption
- **HTTPS** - Use secure HTTP connections
- **Authentication** - Implement device authentication
- **Data Encryption** - Encrypt sensitive data

### Device Security
- **MAC Address Filtering** - Only process known devices
- **Input Validation** - Validate all inputs
- **Error Handling** - Secure error messages
- **Access Control** - Restrict device access

## 📚 API Integration

### Raw Scan Data Transmission
```cpp
// Send raw scan data to server
POST /api/esp32/scan
Headers:
  X-ESP32-ID: ESP32_001
  Content-Type: application/json

Body:
{
    "esp32_id": "ESP32_001",
    "scans": [
        {
            "mac_address": "AA:BB:CC:DD:EE:FF",
            "rssi": -65
        },
        {
            "mac_address": "11:22:33:44:55:66", 
            "rssi": -78
        }
    ]
}
```

### Health Check
```cpp
// Check server health
GET /api/health
```

### Error Handling
```cpp
// Handle HTTP errors
if (httpResponseCode == 200) {
    // Success
} else if (httpResponseCode == 401) {
    // Unauthorized
} else if (httpResponseCode == 500) {
    // Server error
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test on hardware
5. Submit a pull request

## 📝 License

This project is part of the Employee Attendance System and is licensed under the MIT License.

---

**ESP32 Hardware - Automatic Employee Detection and Attendance Logging** 🔧
