# 🖥️ Backend Server - Employee Attendance System

A robust Node.js/Express backend server that manages employee attendance data, user authentication, and provides RESTful APIs for the entire attendance system.

> **📚 [← Back to Main Documentation](../README.md)** | **[📊 Dashboard](../dashboard/README.md)** | **[📱 Mobile App](../mobile/README.md)** | **[🔧 ESP32 Hardware](../esp32/README.md)**

## 🚀 Quick Start

### Prerequisites
- Node.js (v16 or higher)
- MySQL (v8.0 or higher)
- npm or yarn

### Installation
```bash
# Install dependencies
npm install

# Copy environment configuration
cp .env.example .env

# Edit .env with your database credentials
# DB_HOST=localhost
# DB_USER=root
# DB_PASSWORD=your_password
# DB_NAME=attendance_system
# JWT_SECRET=your_jwt_secret
# PORT=3000

# Start the server
npm start
```

## 🏗️ Architecture

### Project Structure
```
backend/
├── src/
│   ├── app.js                 # Express app configuration
│   ├── server.js              # Server entry point
│   ├── config/
│   │   └── db.js              # Database connection
│   ├── controllers/           # API controllers
│   │   ├── authController.js
│   │   ├── employeeController.js
│   │   ├── attendanceController.js
│   │   ├── userController.js
│   │   ├── departmentController.js
│   │   └── esp32Controller.js
│   ├── services/              # Business logic
│   │   ├── authService.js
│   │   ├── employeeService.js
│   │   ├── attendanceService.js
│   │   ├── userService.js
│   │   ├── departmentService.js
│   │   └── esp32Service.js
│   ├── routes/                # API routes
│   │   ├── auth.js
│   │   ├── employees.js
│   │   ├── attendance.js
│   │   ├── users.js
│   │   ├── departments.js
│   │   └── esp32.js
│   └── middleware/            # Custom middleware
│       ├── auth.js
│       └── errorHandler.js
├── package.json
└── README.md
```

## 🔌 API Endpoints

### Authentication (`/api/auth`)
- `POST /login` - User authentication
- `GET /me` - Get current user info
- `POST /logout` - Logout functionality

### Employee Management (`/api/employees`)
- `GET /` - Get all employees (with department info)
- `POST /` - Create new employee
- `PUT /:id` - Update employee
- `DELETE /:id` - Delete employee

### Department Management (`/api/departments`)
- `GET /` - Get all departments
- `GET /:id` - Get department by ID
- `POST /` - Create new department
- `PUT /:id` - Update department
- `DELETE /:id` - Delete department

### Attendance Tracking (`/api/attendance`)
- `POST /` - Log attendance (public for ESP32/mobile)
- `GET /` - Get attendance logs (public for ESP32/mobile)
- `GET /employee/:id` - Get employee attendance (protected)
- `GET /report` - Get attendance report (protected)
- `PUT /:id` - Update attendance log (protected)
- `DELETE /:id` - Delete attendance log (protected)

### User Management (`/api/users`)
- `GET /` - Get all users (protected)
- `GET /:id` - Get user by ID (protected)
- `POST /` - Create user (protected)
- `PUT /:id` - Update user (protected)
- `DELETE /:id` - Delete user (protected)

### ESP32 Integration (`/api/esp32`)
- `POST /scan` - Receive raw scan data from ESP32 devices

#### ESP32 Data Processing
The backend receives raw Bluetooth scan data from ESP32 devices and processes it intelligently:

1. **Raw Data Reception** - ESP32 sends all detected MAC addresses + RSSI
2. **Employee Matching** - Backend matches MAC addresses to employee database
3. **Entry/Exit Logic** - Determines entry/exit based on signal strength thresholds
4. **Attendance Logging** - Saves processed data directly to `attendance_logs` table
5. **Status Updates** - Updates employee presence status in real-time

#### Signal Strength Thresholds
- **Entry Detection**: RSSI > -70dBm (strong signal = employee entering)
- **Exit Detection**: RSSI < -80dBm (weak signal = employee leaving)
- **No Action**: -80dBm to -70dBm (middle range = no change)

## 🗄️ Database Schema

### Tables
- **`departments`** - Organizational departments
- **`employees`** - Employee information with department assignments
- **`attendance_logs`** - Real-time attendance records (includes ESP32 data)
- **`users`** - System user accounts
- **`roles`** - User role definitions
- **`esp32_devices`** - ESP32 scanner device management

### Key Features
- **Foreign Key Relationships** - Proper data integrity
- **Unique Constraints** - Employee ID and email uniqueness
- **Real-time Updates** - Presence status tracking
- **Department Integration** - Employee-department relationships

## 🔐 Security Features

### Authentication & Authorization
- **JWT Tokens** - Secure token-based authentication
- **Password Hashing** - bcrypt encryption
- **Role-based Access** - Different permission levels
- **Protected Routes** - Middleware-based protection

### API Security
- **Rate Limiting** - 100 requests per 15 minutes
- **CORS** - Cross-origin resource sharing
- **Input Validation** - Request parameter validation
- **SQL Injection Prevention** - Prepared statements
- **Error Handling** - Secure error responses

## 🛠️ Development

### Available Scripts
```bash
# Start development server
npm run dev

# Start production server
npm start

# Run tests
npm test

# Run tests with coverage
npm run test:coverage
```

### Environment Variables
```env
# Database Configuration
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=attendance_system

# Server Configuration
PORT=3000
NODE_ENV=development

# Security
JWT_SECRET=your_jwt_secret_key

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

## 🧪 Testing

### Unit Tests
```bash
# Run all tests
npm test

# Run tests with coverage
npm run test:coverage

# Run specific test file
npm test -- attendance.test.js
```

### Test Structure
```
tests/
├── auth.test.js              # Authentication tests
├── employees.test.js         # Employee management tests
├── attendance.test.js        # Attendance tracking tests
├── users.test.js            # User management tests
└── departments.test.js      # Department management tests
```

### API Testing
```bash
# Test authentication
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Test employee creation
curl -X POST http://localhost:3000/api/employees \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{"employee_id":"EMP001","name":"John Doe","email":"john@example.com","department_id":1}'
```

## 📊 Real-time Features

### Attendance Tracking
- **Automatic Detection** - ESP32 dumb scanner integration
- **Smart Processing** - Backend processes raw ESP32 data
- **Manual Logging** - Mobile app check-in/out
- **Real-time Updates** - Live presence status
- **Source Tracking** - ESP32 vs mobile logging

### Data Synchronization
- **Employee Presence** - Real-time status updates
- **Department Information** - JOIN queries for complete data
- **Attendance Statistics** - Calculated on-demand
- **User Sessions** - JWT token management

## 🔧 Configuration

### Database Connection
```javascript
// config/db.js
const mysql = require('mysql2');

const db = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});
```

### Middleware Configuration
```javascript
// Rate limiting
app.use(rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests, please try again later.'
}));

// CORS
app.use(cors());

// Body parsing
app.use(express.json());
```

## 🚀 Deployment

### Production Setup
1. **Environment Configuration**
   ```bash
   NODE_ENV=production
   DB_HOST=your_production_db_host
   JWT_SECRET=your_secure_jwt_secret
   ```

2. **Database Migration**
   ```bash
   # Import production schema
   mysql -u root -p attendance_system < schema.sql
   ```

3. **Process Management**
   ```bash
   # Using PM2
   npm install -g pm2
   pm2 start src/server.js --name "attendance-backend"
   pm2 save
   pm2 startup
   ```

### Docker Deployment
```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

## 📈 Monitoring & Logging

### Health Checks
```bash
# Check server status
curl http://localhost:3000/api/health

# Check database connection
curl http://localhost:3000/api/health/db
```

### Logging
- **Request Logging** - All API requests
- **Error Logging** - Detailed error information
- **Authentication Logging** - Login attempts and failures
- **Database Logging** - Query performance and errors

## 🐛 Troubleshooting

### Common Issues

#### Database Connection
```bash
# Check MySQL service
sudo systemctl status mysql

# Test connection
mysql -u root -p -e "SHOW DATABASES;"
```

#### Port Conflicts
```bash
# Check port usage
lsof -i :3000

# Kill process using port
kill -9 $(lsof -t -i:3000)
```

#### JWT Issues
```bash
# Verify JWT_SECRET is set
echo $JWT_SECRET

# Check token validity
node -e "console.log(require('jsonwebtoken').verify('YOUR_TOKEN', process.env.JWT_SECRET))"
```

## 📚 API Documentation

### Request/Response Examples

#### Login Request
```json
POST /api/auth/login
{
  "username": "admin",
  "password": "admin123"
}
```

#### Login Response
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "username": "admin",
    "role_id": 1
  }
}
```

#### Employee Creation
```json
POST /api/employees
{
  "employee_id": "EMP001",
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "+1234567890",
  "bluetooth_mac": "AA:BB:CC:DD:EE:FF",
  "department_id": 1
}
```

#### ESP32 Scan Data
```json
POST /api/esp32/scan
Headers:
  X-ESP32-ID: ESP32_001
  Content-Type: application/json

Body:
{
  "esp32_id": "ESP32_001",
  "scans": [
    {
      "mac_address": "AA:BB:CC:DD:EE:FF",
      "rssi": -65
    },
    {
      "mac_address": "11:22:33:44:55:66",
      "rssi": -78
    }
  ]
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## 📝 License

This project is part of the Employee Attendance System and is licensed under the MIT License.

---

**Backend Server - Powering the Employee Attendance System** 🚀
