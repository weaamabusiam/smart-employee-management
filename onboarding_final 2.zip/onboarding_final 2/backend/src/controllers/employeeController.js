// Employee Controller
const employeeService = require('../services/employeeService');

exports.getAllEmployees = async (req, res) => {
  try {
    console.log('getAllEmployees called with user:', req.user);
    
    // For managers (role_id = 2), only show employees from their department
    let userDepartmentId = null;
    if (req.user && req.user.role_id === 2) {
      console.log('Manager detected, getting department ID for user:', req.user.id);
      // Get the manager's department ID from their employee record
      const db = require('../config/db');
      const managerEmployee = await new Promise((resolve, reject) => {
        db.query(
          'SELECT department_id FROM employees WHERE user_id = ?', 
          [req.user.id],
          (err, results) => {
            if (err) return reject(err);
            resolve(results);
          }
        );
      });
      console.log('Manager employee query result:', managerEmployee);
      if (managerEmployee.length > 0) {
        userDepartmentId = managerEmployee[0].department_id;
        console.log('Filtering by department ID:', userDepartmentId);
      }
    }
    
    const employees = await employeeService.getAllEmployees(userDepartmentId);
    console.log('Returning employees count:', employees.length);
    res.json(employees);
  } catch (err) {
    console.error('Error in getAllEmployees:', err);
    res.status(500).json({ error: err.message });
  }
};

exports.addEmployee = async (req, res) => {
  try {
    const { employee_id, name, email, phone, bluetooth_mac, department_id, user_id } = req.body;
    if (!employee_id || !name || !email) {
      return res.status(400).json({ error: 'employee_id, name and email are required' });
    }
    const employee = await employeeService.addEmployee(employee_id, name, email, phone, bluetooth_mac, department_id, user_id);
    res.status(201).json(employee);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    const { employee_id, name, email, phone, bluetooth_mac, department_id, user_id } = req.body;
    if (!employee_id || !name || !email) {
      return res.status(400).json({ error: 'employee_id, name and email are required' });
    }
    const employee = await employeeService.updateEmployee(id, employee_id, name, email, phone, bluetooth_mac, department_id, user_id);
    res.json(employee);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    await employeeService.deleteEmployee(id);
    res.json({ message: 'Employee deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

