const express = require('express');
const router = express.Router();
const attendanceController = require('../controllers/attendanceController');
const { authenticateJWT } = require('../middleware/auth');

// Public routes (for ESP32 and mobile app)
router.post('/', attendanceController.logAttendance);
router.get('/', attendanceController.getAttendanceLogs);

// Protected routes for mobile app
router.get('/my-attendance', authenticateJWT, attendanceController.getMyAttendance);

// Protected routes (for dashboard)
router.get('/employee/:id', authenticateJWT, attendanceController.getEmployeeAttendance);
router.get('/report', authenticateJWT, attendanceController.getAttendanceReport);
router.put('/:id', authenticateJWT, attendanceController.updateAttendanceLog);
router.delete('/:id', authenticateJWT, attendanceController.deleteAttendanceLog);

module.exports = router;

