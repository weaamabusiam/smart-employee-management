const express = require('express');
const router = express.Router();
const esp32Controller = require('../controllers/esp32Controller');
const { authenticateJWT } = require('../middleware/auth');
const { requireDashboardAccess } = require('../middleware/roleBasedAuth');

// ESP32 sends scan results (no auth required - ESP32 devices)
router.post('/scan', esp32Controller.processScanResults);

// Get ESP32 status (no auth required - for monitoring)
router.get('/status', esp32Controller.getStatus);

// Dashboard routes - require authentication and dashboard access
router.use(authenticateJWT);
router.use(requireDashboardAccess);

// Register new ESP32 device
router.post('/register', esp32Controller.registerDevice);

// Get all ESP32 devices
router.get('/devices', esp32Controller.getDevices);

// Update ESP32 device
router.put('/devices/:id', esp32Controller.updateDevice);

// Delete ESP32 device
router.delete('/devices/:id', esp32Controller.deleteDevice);

module.exports = router;
