const express = require('express');
const router = express.Router();
const attendanceService = require('../services/attendanceService');

// Test endpoint to simulate ESP32 logging attendance
router.post('/simulate-esp32-attendance', async (req, res) => {
  try {
    const { employee_id, status } = req.body;
    
    if (!employee_id || !status) {
      return res.status(400).json({ 
        error: 'employee_id and status are required' 
      });
    }

    // Log attendance as if it came from ESP32
    const result = await attendanceService.logAttendance(employee_id, status, 'esp32');
    
    res.json({
      success: true,
      message: `ESP32 logged attendance: Employee ${employee_id} is now ${status}`,
      data: result
    });
  } catch (error) {
    console.error('Test attendance logging error:', error);
    res.status(500).json({ 
      error: error.message || 'Failed to log test attendance' 
    });
  }
});

module.exports = router;

