// Attendance Service
const db = require('../config/db');
const notificationService = require('./notificationService');

exports.logAttendance = async (employee_id, status, source = 'unknown') => {
  return new Promise(async (resolve, reject) => {
    try {
      // First, find the employee by id (the mobile app sends the employees.id value)
      const employeeQuery = 'SELECT id FROM employees WHERE id = ?';
      const employeeResult = await new Promise((resolveEmp, rejectEmp) => {
        db.query(employeeQuery, [employee_id], (err, results) => {
          if (err) return rejectEmp(err);
          resolveEmp(results);
        });
      });

      if (employeeResult.length === 0) {
        return reject(new Error('Employee not found'));
      }

      const employeeDbId = employeeResult[0].id;

      // Log the attendance
      const query = 'INSERT INTO attendance_logs (employee_id, status, source) VALUES (?, ?, ?)';
      db.query(query, [employeeDbId, status, source], (err, result) => {
        if (err) return reject(err);
        
        // Update employee presence status
        const presenceQuery = 'UPDATE employees SET is_present = ? WHERE id = ?';
        const isPresent = status === 'present';
        db.query(presenceQuery, [isPresent, employeeDbId], (err) => {
          if (err) console.error('Failed to update presence:', err);
        });
        
        // Send notification if attendance was logged by ESP32
        if (source === 'esp32') {
          notificationService.sendAttendanceNotification(employeeDbId, status, source)
            .catch(err => console.error('Failed to send notification:', err));
        }
        
        resolve({ id: result.insertId, employee_id, status, source, timestamp: new Date() });
      });
    } catch (err) {
      reject(err);
    }
  });
};

exports.getAttendanceLogs = async (employee_id = null, date = null, limit = 100) => {
  return new Promise((resolve, reject) => {
    let query = 'SELECT * FROM attendance_logs';
    let params = [];
    
    if (employee_id) {
      query += ' WHERE employee_id = ?';
      params.push(employee_id);
    }
    
    if (date) {
      query += employee_id ? ' AND DATE(timestamp) = ?' : ' WHERE DATE(timestamp) = ?';
      params.push(date);
    }
    
    query += ' ORDER BY timestamp DESC LIMIT ?';
    params.push(parseInt(limit));
    
    db.query(query, params, (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
};

exports.getEmployeeAttendance = async (employee_id, start_date = null, end_date = null) => {
  return new Promise((resolve, reject) => {
    let query = 'SELECT * FROM attendance_logs WHERE employee_id = ?';
    let params = [employee_id];
    
    if (start_date && end_date) {
      query += ' AND DATE(timestamp) BETWEEN ? AND ?';
      params.push(start_date, end_date);
    }
    
    query += ' ORDER BY timestamp DESC';
    
    db.query(query, params, (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
};

exports.getAttendanceReport = async (start_date = null, end_date = null, status = null, department_id = null) => {
  return new Promise((resolve, reject) => {
    let query = `
      SELECT 
        al.*,
        e.name as employee_name,
        e.email as employee_email,
        e.department_id,
        d.name as department_name
      FROM attendance_logs al
      JOIN employees e ON al.employee_id = e.id
      LEFT JOIN departments d ON e.department_id = d.id
    `;
    let params = [];
    let conditions = [];
    
    if (start_date && end_date) {
      conditions.push('DATE(al.timestamp) BETWEEN ? AND ?');
      params.push(start_date, end_date);
    }
    
    if (status) {
      conditions.push('al.status = ?');
      params.push(status);
    }
    
    // Filter by department if specified (for managers)
    if (department_id) {
      conditions.push('e.department_id = ?');
      params.push(department_id);
    }
    
    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }
    
    query += ' ORDER BY al.timestamp DESC';
    
    db.query(query, params, (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
};

exports.updateAttendanceLog = async (id, updates) => {
  return new Promise((resolve, reject) => {
    const fields = [];
    const values = [];
    
    Object.keys(updates).forEach(key => {
      if (updates[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(updates[key]);
      }
    });
    
    if (fields.length === 0) {
      return resolve(null);
    }
    
    values.push(id);
    const query = `UPDATE attendance_logs SET ${fields.join(', ')} WHERE id = ?`;
    
    db.query(query, values, (err, result) => {
      if (err) return reject(err);
      if (result.affectedRows === 0) return resolve(null);
      
      // Return the updated record
      db.query('SELECT * FROM attendance_logs WHERE id = ?', [id], (err, results) => {
        if (err) return reject(err);
        resolve(results[0]);
      });
    });
  });
};

exports.deleteAttendanceLog = async (id) => {
  return new Promise((resolve, reject) => {
    const query = 'DELETE FROM attendance_logs WHERE id = ?';
    db.query(query, [id], (err, result) => {
      if (err) return reject(err);
      if (result.affectedRows === 0) {
        reject(new Error('Attendance log not found'));
      } else {
        resolve();
      }
    });
  });
};

