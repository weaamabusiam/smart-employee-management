// Employee Service
const db = require('../config/db');

exports.getAllEmployees = (userDepartmentId = null) => {
  return new Promise((resolve, reject) => {
    let query = `
      SELECT e.*, d.name as department_name, u.username, r.name as role_name
      FROM employees e 
      LEFT JOIN departments d ON e.department_id = d.id 
      LEFT JOIN users u ON e.user_id = u.id
      LEFT JOIN roles r ON u.role_id = r.id
    `;
    
    let params = [];
    
    // If userDepartmentId is provided, filter by department (for managers)
    if (userDepartmentId) {
      query += ` WHERE e.department_id = ?`;
      params.push(userDepartmentId);
    }
    
    query += ` ORDER BY e.name`;
    
    db.query(query, params, (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
};

exports.addEmployee = (employee_id, name, email, phone, bluetooth_mac, department_id, user_id) => {
  return new Promise((resolve, reject) => {
    db.query('INSERT INTO employees (employee_id, name, email, phone, bluetooth_mac, department_id, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)', 
      [employee_id, name, email, phone, bluetooth_mac, department_id, user_id || null], (err, result) => {
      if (err) return reject(err);
      resolve({ id: result.insertId, employee_id, name, email, phone, bluetooth_mac, department_id, user_id });
    });
  });
};

exports.updateEmployee = (id, employee_id, name, email, phone, bluetooth_mac, department_id, user_id) => {
  return new Promise((resolve, reject) => {
    db.query('UPDATE employees SET employee_id = ?, name = ?, email = ?, phone = ?, bluetooth_mac = ?, department_id = ?, user_id = ? WHERE id = ?', 
      [employee_id, name, email, phone, bluetooth_mac, department_id, user_id || null, id], (err, result) => {
      if (err) return reject(err);
      resolve({ id, employee_id, name, email, phone, bluetooth_mac, department_id, user_id });
    });
  });
};

exports.deleteEmployee = (id) => {
  return new Promise((resolve, reject) => {
    db.query('DELETE FROM employees WHERE id = ?', [id], (err, result) => {
      if (err) return reject(err);
      resolve({ id });
    });
  });
};

exports.updateEmployeePresence = (employee_id, is_present) => {
  return new Promise((resolve, reject) => {
    db.query('UPDATE employees SET is_present = ? WHERE employee_id = ?', 
      [is_present, employee_id], (err, result) => {
      if (err) return reject(err);
      resolve({ employee_id, is_present });
    });
  });
};

