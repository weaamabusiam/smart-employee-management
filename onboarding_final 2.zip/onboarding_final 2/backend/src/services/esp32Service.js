const db = require('../config/db');

// Process scan results from ESP32
exports.processScanResults = async (scanData) => {
  const { esp32_id, devices } = scanData;
  const attendance_events = [];
  let processed = 0;

  // Update ESP32 last_seen timestamp
  await updateEsp32LastSeen(esp32_id);

  // Get all employees with their Bluetooth MAC addresses
  const employees = await getEmployeesWithMacAddresses();
  
  // Create a map for quick lookup
  const employeeMap = new Map();
  employees.forEach(emp => {
    if (emp.bluetooth_mac) {
      employeeMap.set(emp.bluetooth_mac.toLowerCase(), emp);
    }
  });

  // Process each detected device
  for (const device of devices) {
    const mac = device.mac.toLowerCase();
    const rssi = device.rssi;
    
    // Check if this MAC belongs to a registered employee
    if (employeeMap.has(mac)) {
      const employee = employeeMap.get(mac);
      
      // Determine if this is entry or exit based on signal strength
      const event_type = determineEntryExit(employee, rssi, esp32_id);
      
      if (event_type) {
        // Create attendance event and save directly to attendance_logs
        const attendanceEvent = await saveAttendanceEvent({
          employee_id: employee.id,
          esp32_id: esp32_id,
          event_type: event_type, // 'entry' or 'exit'
          rssi: rssi,
          timestamp: new Date()
        });
        
        // Update employee presence status
        await updateEmployeePresence(employee.id, event_type === 'entry');
        
        attendance_events.push(attendanceEvent);
        processed++;
        
        console.log(`Employee ${employee.name} ${event_type} detected (RSSI: ${rssi})`);
      }
    }
  }

  return { processed, attendance_events };
};

// Get employees with their Bluetooth MAC addresses
const getEmployeesWithMacAddresses = () => {
  return new Promise((resolve, reject) => {
    db.query(`
      SELECT id, employee_id, name, bluetooth_mac, is_present, department_id
      FROM employees 
      WHERE bluetooth_mac IS NOT NULL AND bluetooth_mac != ''
    `, (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
};

// Determine if this is an entry or exit event
const determineEntryExit = (employee, rssi, esp32_id) => {
  const ENTRY_RSSI_THRESHOLD = -70; // dBm
  const EXIT_RSSI_THRESHOLD = -80;  // dBm
  
  // If employee is currently present and signal is weak, it's an exit
  if (employee.is_present && rssi < EXIT_RSSI_THRESHOLD) {
    return 'exit';
  }
  
  // If employee is not present and signal is strong, it's an entry
  if (!employee.is_present && rssi > ENTRY_RSSI_THRESHOLD) {
    return 'entry';
  }
  
  // No event if signal strength is in the middle range
  return null;
};

// Save attendance event to database
const saveAttendanceEvent = (event) => {
  return new Promise((resolve, reject) => {
    // Map event_type to status for attendance_logs table
    const status = event.event_type === 'entry' ? 'present' : 'absent';
    
    db.query(`
      INSERT INTO attendance_logs (employee_id, timestamp, status, source, esp32_id, rssi)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [
      event.employee_id,
      event.timestamp,
      status,
      'esp32',
      event.esp32_id,
      event.rssi
    ], (err, result) => {
      if (err) return reject(err);
      resolve({
        id: result.insertId,
        employee_id: event.employee_id,
        timestamp: event.timestamp,
        status: status,
        esp32_id: event.esp32_id,
        rssi: event.rssi
      });
    });
  });
};

// Update employee presence status
const updateEmployeePresence = (employeeId, isPresent) => {
  return new Promise((resolve, reject) => {
    db.query(`
      UPDATE employees 
      SET is_present = ?, last_seen = NOW()
      WHERE id = ?
    `, [isPresent, employeeId], (err, result) => {
      if (err) return reject(err);
      resolve(result);
    });
  });
};

// Update ESP32 last_seen timestamp
const updateEsp32LastSeen = (esp32_id) => {
  return new Promise((resolve, reject) => {
    db.query(`
      UPDATE esp32_devices 
      SET last_seen = NOW()
      WHERE esp32_id = ?
    `, [esp32_id], (err, result) => {
      if (err) return reject(err);
      resolve(result);
    });
  });
};

// Get ESP32 status
exports.getStatus = async () => {
  return new Promise((resolve, reject) => {
    db.query(`
      SELECT 
        COUNT(DISTINCT e.id) as total_employees,
        SUM(CASE WHEN e.is_present = 1 THEN 1 ELSE 0 END) as present_employees,
        COUNT(DISTINCT esp32_id) as active_scanners
      FROM employees e
      LEFT JOIN attendance_logs a ON e.id = a.employee_id
      WHERE a.timestamp >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    `, (err, results) => {
      if (err) return reject(err);
      resolve(results[0] || { total_employees: 0, present_employees: 0, active_scanners: 0 });
    });
  });
};

// Register new ESP32 device
exports.registerDevice = async (deviceData) => {
  const { esp32_id, location, description } = deviceData;
  
  return new Promise((resolve, reject) => {
    db.query(`
      INSERT INTO esp32_devices (esp32_id, location, description, status, created_at)
      VALUES (?, ?, ?, 'active', NOW())
      ON DUPLICATE KEY UPDATE
      location = VALUES(location),
      description = VALUES(description),
      status = 'active',
      last_seen = NOW()
    `, [esp32_id, location, description], (err, result) => {
      if (err) return reject(err);
      resolve({ esp32_id, location, description, status: 'active' });
    });
  });
};

// Get all ESP32 devices
exports.getDevices = async () => {
  return new Promise((resolve, reject) => {
    db.query(`
      SELECT 
        id,
        esp32_id,
        location,
        description,
        status,
        last_seen,
        created_at
      FROM esp32_devices
      ORDER BY created_at DESC
    `, (err, results) => {
      if (err) return reject(err);
      resolve(results);
    });
  });
};

// Update ESP32 device
exports.updateDevice = async (id, updateData) => {
  const { location, description, status } = updateData;
  
  return new Promise((resolve, reject) => {
    db.query(`
      UPDATE esp32_devices 
      SET location = ?, description = ?, status = ?
      WHERE id = ?
    `, [location, description, status, id], (err, result) => {
      if (err) return reject(err);
      if (result.affectedRows === 0) {
        return reject(new Error('ESP32 device not found'));
      }
      resolve({ id, location, description, status });
    });
  });
};

// Delete ESP32 device
exports.deleteDevice = async (id) => {
  return new Promise((resolve, reject) => {
    db.query(`
      DELETE FROM esp32_devices 
      WHERE id = ?
    `, [id], (err, result) => {
      if (err) return reject(err);
      if (result.affectedRows === 0) {
        return reject(new Error('ESP32 device not found'));
      }
      resolve({ id });
    });
  });
};
