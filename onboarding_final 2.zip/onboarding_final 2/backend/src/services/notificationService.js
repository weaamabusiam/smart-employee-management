const axios = require('axios');

class NotificationService {
  constructor() {
    this.expoPushUrl = 'https://exp.host/--/api/v2/push/send';
  }

  async sendNotification(expoPushToken, title, body, data = {}) {
    try {
      const message = {
        to: expoPushToken,
        sound: 'default',
        title: title,
        body: body,
        data: data,
      };

      const response = await axios.post(this.expoPushUrl, message, {
        headers: {
          'Accept': 'application/json',
          'Accept-encoding': 'gzip, deflate',
          'Content-Type': 'application/json',
        },
      });

      console.log('Notification sent successfully:', response.data);
      return response.data;
    } catch (error) {
      console.error('Failed to send notification:', error.response?.data || error.message);
      throw error;
    }
  }

  async sendAttendanceNotification(employeeId, status, source = 'esp32') {
    try {
      // For now, we'll just log the notification
      // In a real implementation, you'd store expo push tokens for each employee
      console.log(`📱 Notification: Employee ${employeeId} ${status} via ${source}`);
      
      // TODO: Implement actual push notification sending
      // This would require storing Expo push tokens for each employee
      // and sending notifications to their devices
      
      return { success: true, message: 'Notification logged' };
    } catch (error) {
      console.error('Failed to send attendance notification:', error);
      throw error;
    }
  }
}

module.exports = new NotificationService();

