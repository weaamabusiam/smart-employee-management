// ===========================================
// ATTENDANCE SYSTEM - CONFIGURATION EXAMPLE
// ===========================================
// Copy this file to config.js and update the values

module.exports = {
  // ===========================================
  // BACKEND CONFIGURATION
  // ===========================================
  
  server: {
    NODE_ENV: 'development',
    PORT: 3001,
    HOST: 'localhost'
  },

  database: {
    HOST: 'localhost',
    PORT: 3306,
    NAME: 'attendance_system',
    USER: 'root',
    PASSWORD: 'your_mysql_password',
    DIALECT: 'mysql'
  },

  jwt: {
    SECRET: 'your_super_secret_jwt_key_change_this_in_production',
    EXPIRES_IN: '24h',
    REFRESH_EXPIRES_IN: '7d'
  },

  cors: {
    ORIGIN: 'http://localhost:3000,http://localhost:5173'
  },

  rateLimit: {
    WINDOW_MS: 900000,
    MAX_REQUESTS: 100
  },

  // ===========================================
  // FRONTEND CONFIGURATION
  // ===========================================
  
  frontend: {
    API_BASE_URL: 'http://localhost:3001/api',
    APP_TITLE: 'Attendance Management System',
    APP_VERSION: '1.0.0'
  },

  // ===========================================
  // MOBILE APP CONFIGURATION
  // ===========================================
  
  mobile: {
    API_BASE_URL: 'http://localhost:3001/api',
    APP_NAME: 'Attendance Mobile',
    BLUETOOTH_SCAN_DURATION: 10000,
    BLUETOOTH_CONNECTION_TIMEOUT: 5000
  },

  // ===========================================
  // ESP32 CONFIGURATION
  // ===========================================
  
  esp32: {
    DEVICE_NAME: 'ESP32_Attendance_Scanner',
    SCAN_INTERVAL: 5000,
    SERVER_URL: 'http://localhost:3001/api/esp32/scan'
  },

  // ===========================================
  // NOTIFICATION CONFIGURATION
  // ===========================================
  
  notifications: {
    email: {
      HOST: 'smtp.gmail.com',
      PORT: 587,
      USER: 'your_email@gmail.com',
      PASS: 'your_app_password',
      FROM: 'noreply@attendance-system.com'
    },
    push: {
      FCM_SERVER_KEY: 'your_fcm_server_key',
      FCM_SENDER_ID: 'your_fcm_sender_id'
    }
  },

  // ===========================================
  // SECURITY CONFIGURATION
  // ===========================================
  
  security: {
    password: {
      MIN_LENGTH: 8,
      REQUIRE_SPECIAL_CHARS: true,
      REQUIRE_NUMBERS: true,
      REQUIRE_UPPERCASE: true
    },
    session: {
      SECRET: 'your_session_secret_key',
      COOKIE_MAX_AGE: 86400000
    }
  },

  // ===========================================
  // LOGGING CONFIGURATION
  // ===========================================
  
  logging: {
    LEVEL: 'info',
    FILE: 'logs/app.log',
    MAX_SIZE: '10m',
    MAX_FILES: 5
  },

  // ===========================================
  // DEVELOPMENT CONFIGURATION
  // ===========================================
  
  development: {
    DEBUG: true,
    VERBOSE_LOGGING: true,
    HOT_RELOAD: true
  }
};
