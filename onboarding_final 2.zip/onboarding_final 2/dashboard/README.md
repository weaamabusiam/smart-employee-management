# 📊 Dashboard - Employee Attendance System

A modern, responsive React dashboard for managing employee attendance, built with Vite and featuring a comprehensive admin interface with real-time updates and advanced analytics.

> **📚 [← Back to Main Documentation](../README.md)** | **[🖥️ Backend Server](../backend/README.md)** | **[📱 Mobile App](../mobile/README.md)** | **[🔧 ESP32 Hardware](../esp32/README.md)**

## 🚀 Quick Start

### Prerequisites
- Node.js (version 16 or higher)
- npm or yarn
- Backend server running (port 3000)

### Installation
```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

### Build for Production
```bash
# Build the application
npm run build

# Preview the build
npm run preview
```

## 🌐 Access the Dashboard

Once you start the development server:
- **Local Development**: http://localhost:5173
- **Network Access**: The terminal will show the network URL for access from other devices
- **Default Login**: Username: `admin`, Password: `admin123`

## 🎯 Features

### 🔐 Authentication System
- **Secure Login** - JWT-based authentication
- **Session Management** - Automatic token handling
- **Role-based Access** - Different permission levels
- **Auto-logout** - Session timeout protection

### 👥 Employee Management
- **Complete CRUD Operations** - Add, edit, delete employees
- **Department Assignment** - Assign employees to departments
- **Bluetooth Device Pairing** - Link employee devices to profiles
- **Search & Filter** - Find employees quickly
- **Bulk Operations** - Manage multiple employees

### 🏢 Department Management
- **Organizational Structure** - Create and manage departments
- **Department Information** - Detailed descriptions and metadata
- **Employee-Department Assignment** - Assign employees to departments
- **Department Statistics** - Employee counts and analytics

### 📊 Advanced Reporting
- **Real-time Dashboard** - Live attendance monitoring
- **Interactive Charts** - 7-day attendance trends
- **Date Range Filtering** - Flexible reporting periods (1, 7, 30, 90 days)
- **Attendance Statistics** - Comprehensive analytics
- **Export Capabilities** - Data export functionality

### 📍 Present Employees View
- **Live Status Tracking** - Real-time presence monitoring
- **Auto-refresh** - Updates every 30 seconds
- **Statistics Cards** - Total, present, absent counts
- **Department Filtering** - Filter by department
- **Status Indicators** - Visual presence indicators

### 👤 User Management
- **User CRUD Operations** - Create, edit, delete users
- **Role Management** - Assign different permission levels
- **Search & Filter** - Find users quickly
- **Password Management** - Secure password handling

## 🛠️ Tech Stack

- **Frontend**: React 19 + Vite
- **Styling**: Inline styles with modern CSS
- **HTTP Client**: Axios
- **Build Tool**: Vite
- **State Management**: React Hooks
- **Authentication**: JWT tokens

## 📁 Project Structure

```
dashboard/
├── src/
│   ├── components/           # React components
│   │   ├── EmployeeTable.jsx        # Employee management
│   │   ├── AttendanceReport.jsx     # Reports and analytics
│   │   ├── PresentEmployees.jsx     # Live presence tracking
│   │   ├── DepartmentManagement.jsx # Department management
│   │   ├── UserManagement.jsx       # User management
│   │   └── LoginForm.jsx            # Authentication
│   ├── services/             # API services
│   │   └── api.js           # Backend API integration
│   ├── App.jsx              # Main application
│   ├── main.jsx             # Entry point
│   └── index.css            # Global styles
├── public/
│   └── vite.svg             # Vite logo
├── package.json
├── vite.config.js           # Vite configuration
└── README.md
```

## 🎨 UI/UX Features

### Modern Design
- **Responsive Layout** - Works on all device sizes
- **Tabbed Interface** - Organized navigation
- **Loading Skeletons** - Smooth loading states
- **Toast Notifications** - User feedback
- **Interactive Charts** - Data visualization
- **Hover Effects** - Enhanced user experience

### Color Scheme
- **Primary**: Blue (#4f46e5)
- **Success**: Green (#10b981)
- **Error**: Red (#ef4444)
- **Warning**: Yellow (#f59e0b)
- **Neutral**: Gray (#6b7280)

### Typography
- **Headings**: Bold, clear hierarchy
- **Body Text**: Readable, consistent spacing
- **Code**: Monospace for technical data
- **Icons**: Emoji and Unicode symbols

## 🔧 Configuration

### API Configuration
The dashboard connects to the backend API. Update `src/services/api.js` if needed:

```javascript
const API_URL = 'http://localhost:3000/api';
```

### Environment Variables
Create `.env` file for custom configuration:

```env
VITE_API_URL=http://localhost:3000/api
VITE_APP_TITLE=Employee Attendance System
```

## 📱 Responsive Design

### Breakpoints
- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

### Mobile Features
- **Touch-friendly** - Large buttons and touch targets
- **Swipe Navigation** - Gesture-based navigation
- **Optimized Layout** - Stacked components on mobile
- **Fast Loading** - Optimized for mobile networks

## 🧪 Testing

### Available Scripts
```bash
# Run development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Run linting
npm run lint
```

### Testing Features
- **Component Testing** - Individual component tests
- **Integration Testing** - API integration tests
- **E2E Testing** - Full user flow tests
- **Performance Testing** - Load and performance tests

## 🎯 Component Details

### EmployeeTable Component
- **Employee Cards** - Visual employee representation
- **Search Functionality** - Real-time search
- **Filter Options** - Department and status filters
- **Form Validation** - Input validation and error handling
- **Bulk Operations** - Select multiple employees

### AttendanceReport Component
- **Interactive Charts** - 7-day attendance trends
- **Date Range Picker** - Flexible time periods
- **Statistics Cards** - Key metrics display
- **Export Options** - Data export functionality
- **Real-time Updates** - Live data refresh

### PresentEmployees Component
- **Live Status** - Real-time presence tracking
- **Auto-refresh** - Automatic updates every 30 seconds
- **Statistics** - Present/absent counts
- **Department Filtering** - Filter by department
- **Status Indicators** - Visual presence indicators

### DepartmentManagement Component
- **CRUD Operations** - Complete department management
- **Employee Assignment** - Assign employees to departments
- **Department Cards** - Visual department representation
- **Search & Filter** - Find departments quickly
- **Validation** - Input validation and error handling

## 🔐 Security Features

### Authentication
- **JWT Tokens** - Secure token-based authentication
- **Auto-logout** - Session timeout protection
- **Protected Routes** - Route-level protection
- **Token Refresh** - Automatic token renewal

### Data Protection
- **Input Sanitization** - XSS prevention
- **CSRF Protection** - Cross-site request forgery protection
- **Secure Headers** - Security headers configuration
- **Error Handling** - Secure error messages

## 🚀 Performance Optimization

### Loading Optimization
- **Code Splitting** - Lazy loading of components
- **Bundle Optimization** - Minimized bundle size
- **Image Optimization** - Optimized images
- **Caching** - Browser caching strategies

### Real-time Updates
- **Efficient Polling** - Optimized API calls
- **Debounced Search** - Reduced API calls
- **Memoization** - React.memo for performance
- **Virtual Scrolling** - Large list optimization

## 🐛 Troubleshooting

### Common Issues

#### Port Already in Use
```bash
# Change port in vite.config.js
export default defineConfig({
  server: {
    port: 5174
  }
})
```

#### API Connection Issues
```bash
# Check backend server
curl http://localhost:3000/api/health

# Check CORS configuration
# Ensure backend allows frontend origin
```

#### Build Errors
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

#### Authentication Issues
```bash
# Clear localStorage
localStorage.clear()

# Check JWT token
console.log(localStorage.getItem('authToken'))
```

## 📊 Analytics & Monitoring

### User Analytics
- **Page Views** - Track page usage
- **User Actions** - Monitor user interactions
- **Performance Metrics** - Load times and responsiveness
- **Error Tracking** - Monitor and log errors

### Business Metrics
- **Attendance Rates** - Employee attendance statistics
- **Department Performance** - Department-wise analytics
- **User Engagement** - Dashboard usage patterns
- **System Health** - API response times and errors

## 🎨 Customization

### Styling
The dashboard uses inline styles for easy customization:

```javascript
const styles = {
  container: {
    padding: '2rem',
    maxWidth: '1200px',
    margin: '0 auto'
  },
  // ... more styles
};
```

### Themes
- **Light Theme** - Default theme
- **Dark Theme** - Dark mode support
- **Custom Colors** - Brand-specific colors
- **Typography** - Custom font families

### Layout
- **Grid System** - Flexible grid layout
- **Spacing** - Consistent spacing system
- **Breakpoints** - Responsive breakpoints
- **Components** - Reusable component library

## 📚 API Integration

### Backend Endpoints
- **Authentication** - Login, logout, user info
- **Employees** - CRUD operations
- **Departments** - Department management
- **Attendance** - Attendance tracking and reports
- **Users** - User management

### Data Flow
1. **User Login** - JWT token generation
2. **Data Fetching** - API calls with authentication
3. **Real-time Updates** - Polling for live data
4. **State Management** - React state management
5. **UI Updates** - Component re-rendering

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure responsive design
6. Submit a pull request

## 📝 License

This project is part of the Employee Attendance System and is licensed under the MIT License.

---

**Dashboard - Modern Admin Interface for Employee Attendance Management** 📊