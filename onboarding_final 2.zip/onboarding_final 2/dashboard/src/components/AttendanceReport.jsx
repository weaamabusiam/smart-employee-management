import React, { useEffect, useState } from 'react';
import { getAttendance } from '../services/api';

export default function AttendanceReport({ user }) {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ present: 0, absent: 0, late: 0, total: 0 });
  const [dateRange, setDateRange] = useState('7'); // days
  const [filteredLogs, setFilteredLogs] = useState([]);
  const [toast, setToast] = useState({ show: false, message: '', type: 'success' });

  useEffect(() => {
    loadAttendance();
  }, [user]); // Reload when user changes

  useEffect(() => {
    filterLogsByDateRange();
  }, [logs, dateRange]);

  const showToast = (message, type = 'success') => {
    setToast({ show: true, message, type });
    setTimeout(() => setToast({ show: false, message: '', type: 'success' }), 3000);
  };

  const loadAttendance = async () => {
    try {
      setLoading(true);
      const data = await getAttendance();
      setLogs(data);
      showToast('Attendance data refreshed successfully!');
    } catch (error) {
      console.error('Failed to load attendance:', error);
      showToast('Failed to load attendance data', 'error');
    } finally {
      setLoading(false);
    }
  };

  const filterLogsByDateRange = () => {
    const days = parseInt(dateRange);
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    const filtered = logs.filter(log => new Date(log.timestamp) >= cutoffDate);
    setFilteredLogs(filtered);
    
    // Calculate statistics for filtered data
    const stats = filtered.reduce((acc, log) => {
      acc[log.status] = (acc[log.status] || 0) + 1;
      acc.total += 1;
      return acc;
    }, { present: 0, absent: 0, late: 0, total: 0 });
    
    setStats(stats);
  };

  const getAttendanceTrend = () => {
    const last7Days = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dayLogs = filteredLogs.filter(log => 
        new Date(log.timestamp).toDateString() === date.toDateString()
      );
      last7Days.push({
        date: date.toLocaleDateString(),
        present: dayLogs.filter(log => log.status === 'present').length,
        absent: dayLogs.filter(log => log.status === 'absent').length,
        late: dayLogs.filter(log => log.status === 'late').length
      });
    }
    return last7Days;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'present': return '#10b981';
      case 'absent': return '#ef4444';
      case 'late': return '#f59e0b';
      default: return '#6b7280';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'present': return '✅';
      case 'absent': return '❌';
      case 'late': return '⏰';
      default: return '❓';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div style={styles.container}>
        <div style={styles.header}>
          <h2 style={styles.title}>📊 Attendance Report</h2>
          <button 
            onClick={loadAttendance}
            style={styles.refreshButton}
            title="Refresh Data"
          >
            🔄 Refresh
          </button>
        </div>
        
        <div style={styles.skeletonStatsGrid}>
          {[1, 2, 3, 4].map(i => (
            <div key={i} style={styles.skeletonStatCard}>
              <div style={styles.skeletonStatIcon}></div>
              <div style={styles.skeletonStatContent}>
                <div style={styles.skeletonStatNumber}></div>
                <div style={styles.skeletonStatLabel}></div>
              </div>
            </div>
          ))}
        </div>
        
        <div style={styles.skeletonLogsSection}>
          <h3 style={styles.sectionTitle}>Recent Attendance Logs</h3>
          <div style={styles.skeletonLogsGrid}>
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} style={styles.skeletonLogCard}>
                <div style={styles.skeletonLogHeader}>
                  <div style={styles.skeletonLogStatus}></div>
                  <div style={styles.skeletonLogId}></div>
                </div>
                <div style={styles.skeletonLogContent}>
                  <div style={styles.skeletonLogLine}></div>
                  <div style={styles.skeletonLogLine}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      {/* Toast Notification */}
      {toast.show && (
        <div style={{
          ...styles.toast,
          ...(toast.type === 'error' ? styles.toastError : styles.toastSuccess)
        }}>
          <span style={styles.toastIcon}>
            {toast.type === 'success' ? '✅' : '❌'}
          </span>
          <span style={styles.toastMessage}>{toast.message}</span>
          <button 
            onClick={() => setToast({ show: false, message: '', type: 'success' })}
            style={styles.toastClose}
          >
            ✕
          </button>
        </div>
      )}

      {/* Header */}
      <div style={styles.header}>
        <h2 style={styles.title}>📊 Attendance Report</h2>
        <button 
          onClick={loadAttendance}
          style={styles.refreshButton}
          title="Refresh Data"
        >
          🔄 Refresh
        </button>
      </div>

      {/* Date Range Filter */}
      <div style={styles.filterSection}>
        <h3 style={styles.filterTitle}>📅 Date Range Filter</h3>
        <div style={styles.filterControls}>
          <select 
            value={dateRange} 
            onChange={(e) => setDateRange(e.target.value)}
            style={styles.dateSelect}
          >
            <option value="1">Last 24 hours</option>
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
          </select>
          <span style={styles.filterInfo}>
            Showing {filteredLogs.length} records from the last {dateRange} day{dateRange !== '1' ? 's' : ''}
          </span>
        </div>
      </div>

      {/* Attendance Trend Chart */}
      <div style={styles.chartSection}>
        <h3 style={styles.chartTitle}>📊 7-Day Attendance Trend</h3>
        <div style={styles.chartContainer}>
          {getAttendanceTrend().map((day, index) => (
            <div key={index} style={styles.chartDay}>
              <div style={styles.chartBars}>
                <div 
                  style={{
                    ...styles.chartBar,
                    height: `${Math.max(day.present * 10, 5)}px`,
                    backgroundColor: '#10b981'
                  }}
                  title={`Present: ${day.present}`}
                ></div>
                <div 
                  style={{
                    ...styles.chartBar,
                    height: `${Math.max(day.absent * 10, 5)}px`,
                    backgroundColor: '#ef4444'
                  }}
                  title={`Absent: ${day.absent}`}
                ></div>
                <div 
                  style={{
                    ...styles.chartBar,
                    height: `${Math.max(day.late * 10, 5)}px`,
                    backgroundColor: '#f59e0b'
                  }}
                  title={`Late: ${day.late}`}
                ></div>
              </div>
              <div style={styles.chartLabel}>{day.date}</div>
            </div>
          ))}
        </div>
        <div style={styles.chartLegend}>
          <div style={styles.legendItem}>
            <div style={{...styles.legendColor, backgroundColor: '#10b981'}}></div>
            <span>Present</span>
          </div>
          <div style={styles.legendItem}>
            <div style={{...styles.legendColor, backgroundColor: '#ef4444'}}></div>
            <span>Absent</span>
          </div>
          <div style={styles.legendItem}>
            <div style={{...styles.legendColor, backgroundColor: '#f59e0b'}}></div>
            <span>Late</span>
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div style={styles.statsGrid}>
        <div style={styles.statCard}>
          <div style={{...styles.statIcon, backgroundColor: '#3b82f6'}}>👥</div>
          <div style={styles.statContent}>
            <h3 style={styles.statNumber}>{stats.total}</h3>
            <p style={styles.statLabel}>Total Records</p>
          </div>
        </div>
        
        <div style={styles.statCard}>
          <div style={{...styles.statIcon, backgroundColor: '#10b981'}}>✅</div>
          <div style={styles.statContent}>
            <h3 style={styles.statNumber}>{stats.present}</h3>
            <p style={styles.statLabel}>Present</p>
          </div>
        </div>
        
        <div style={styles.statCard}>
          <div style={{...styles.statIcon, backgroundColor: '#f59e0b'}}>⏰</div>
          <div style={styles.statContent}>
            <h3 style={styles.statNumber}>{stats.late}</h3>
            <p style={styles.statLabel}>Late</p>
          </div>
        </div>
        
        <div style={styles.statCard}>
          <div style={{...styles.statIcon, backgroundColor: '#ef4444'}}>❌</div>
          <div style={styles.statContent}>
            <h3 style={styles.statNumber}>{stats.absent}</h3>
            <p style={styles.statLabel}>Absent</p>
          </div>
        </div>
      </div>

      {/* Attendance Logs */}
      <div style={styles.logsSection}>
        <h3 style={styles.sectionTitle}>Recent Attendance Logs</h3>
        
        {filteredLogs.length === 0 ? (
          <div style={styles.emptyState}>
            <p style={styles.emptyText}>No attendance records found for the selected period.</p>
          </div>
        ) : (
          <div style={styles.logsGrid}>
            {filteredLogs.slice(0, 10).map(log => (
              <div key={log.id} style={styles.logCard}>
                <div style={styles.logHeader}>
                  <span style={{...styles.logStatus, backgroundColor: getStatusColor(log.status)}}>
                    {getStatusIcon(log.status)} {log.status.toUpperCase()}
                  </span>
                  <span style={styles.logId}>#{log.id}</span>
                </div>
                
                <div style={styles.logContent}>
                  <p style={styles.logEmployee}>👤 Employee ID: {log.employee_id}</p>
                  <p style={styles.logTime}>🕒 {formatDate(log.timestamp)}</p>
                  {log.source && <p style={styles.logSource}>📱 Source: {log.source}</p>}
                </div>
              </div>
            ))}
          </div>
        )}
        
        {logs.length > 10 && (
          <div style={styles.viewMore}>
            <p style={styles.viewMoreText}>
              Showing 10 of {logs.length} records. 
              <button style={styles.viewMoreButton}>View All Records</button>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '1400px',
    margin: '0 auto',
    minHeight: '100vh',
    background: 'linear-gradient(135deg, #0f0f23 0%, #1a1a2e 50%, #16213e 100%)',
    color: '#ffffff'
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '2.5rem',
    padding: '2rem',
    background: 'rgba(255, 255, 255, 0.03)',
    borderRadius: '20px',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    backdropFilter: 'blur(10px)',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)',
    flexWrap: 'wrap',
    gap: '1rem'
  },
  title: {
    fontSize: '2.5rem',
    fontWeight: '800',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    margin: '0',
    flex: '1',
    minWidth: '200px',
    textShadow: '0 4px 8px rgba(0, 0, 0, 0.3)'
  },
  refreshButton: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    border: '1px solid rgba(255, 255, 255, 0.2)',
    borderRadius: '50px',
    padding: '1rem 2rem',
    fontSize: '1rem',
    fontWeight: '700',
    cursor: 'pointer',
    transition: '0.4s cubic-bezier(0.4, 0, 0.2, 1)',
    boxShadow: 'rgba(102, 126, 234, 0.3) 0px 8px 25px',
    backdropFilter: 'blur(10px)',
    position: 'relative',
    overflow: 'hidden',
    flexShrink: '0',
    whiteSpace: 'nowrap',
    '&:hover': {
      transform: 'translateY(-3px) scale(1.05)',
      boxShadow: 'rgba(102, 126, 234, 0.4) 0px 15px 35px',
      filter: 'brightness(1.1)'
    },
    '&:active': {
      transform: 'translateY(-1px) scale(1.02)'
    }
  },
  filterSection: {
    background: 'rgba(255, 255, 255, 0.03)',
    padding: '2rem',
    borderRadius: '16px',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    backdropFilter: 'blur(10px)',
    marginBottom: '2rem',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)'
  },
  filterTitle: {
    fontSize: '1.5rem',
    fontWeight: '700',
    color: '#ffffff',
    margin: '0 0 1.5rem 0',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent'
  },
  filterControls: {
    display: 'flex',
    alignItems: 'center',
    gap: '1.5rem',
    flexWrap: 'wrap'
  },
  dateSelect: {
    padding: '1rem 1.25rem',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    borderRadius: '12px',
    fontSize: '1rem',
    background: 'rgba(255, 255, 255, 0.05)',
    color: '#ffffff',
    cursor: 'pointer',
    transition: '0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    backdropFilter: 'blur(10px)',
    '&:focus': {
      outline: 'none',
      borderColor: 'rgba(102, 126, 234, 0.5)',
      boxShadow: '0 0 0 3px rgba(102, 126, 234, 0.1)'
    }
  },
  filterInfo: {
    fontSize: '1rem',
    color: 'rgba(255, 255, 255, 0.7)',
    fontWeight: '500'
  },
  chartSection: {
    background: 'rgba(255, 255, 255, 0.03)',
    padding: '2rem',
    borderRadius: '16px',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    backdropFilter: 'blur(10px)',
    marginBottom: '2rem',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)'
  },
  chartTitle: {
    fontSize: '1.5rem',
    fontWeight: '700',
    color: '#ffffff',
    margin: '0 0 1.5rem 0',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent'
  },
  chartContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'end',
    height: '250px',
    marginBottom: '1.5rem',
    padding: '1.5rem 0'
  },
  chartDay: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    flex: '1',
    margin: '0 4px'
  },
  chartBars: {
    display: 'flex',
    alignItems: 'end',
    gap: '4px',
    height: '180px',
    marginBottom: '1rem'
  },
  chartBar: {
    width: '24px',
    minHeight: '8px',
    borderRadius: '4px 4px 0 0',
    transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
    '&:hover': {
      transform: 'scale(1.05)',
      filter: 'brightness(1.1)'
    }
  },
  chartLabel: {
    fontSize: '0.8rem',
    color: 'rgba(255, 255, 255, 0.7)',
    textAlign: 'center',
    transform: 'rotate(-45deg)',
    whiteSpace: 'nowrap',
    fontWeight: '500'
  },
  chartLegend: {
    display: 'flex',
    justifyContent: 'center',
    gap: '3rem',
    marginTop: '1.5rem'
  },
  legendItem: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    fontSize: '0.9rem',
    color: 'rgba(255, 255, 255, 0.8)',
    fontWeight: '500'
  },
  legendColor: {
    width: '16px',
    height: '16px',
    borderRadius: '4px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)'
  },
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '1.5rem',
    marginBottom: '2.5rem',
    width: '100%'
  },
  statCard: {
    background: 'rgba(255, 255, 255, 0.05)',
    borderRadius: '16px',
    padding: '2rem',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(10px)',
    display: 'flex',
    alignItems: 'center',
    gap: '1.5rem',
    width: '100%',
    boxSizing: 'border-box',
    transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
    cursor: 'pointer',
    position: 'relative',
    overflow: 'hidden',
    '&:hover': {
      transform: 'translateY(-8px) scale(1.02)',
      boxShadow: '0 20px 40px rgba(0, 0, 0, 0.4)',
      borderColor: 'rgba(102, 126, 234, 0.5)'
    }
  },
  statIcon: {
    width: '60px',
    height: '60px',
    borderRadius: '16px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '1.8rem',
    flexShrink: '0',
    boxShadow: '0 8px 16px rgba(0, 0, 0, 0.3)'
  },
  statContent: {
    flex: '1',
    minWidth: '0'
  },
  statNumber: {
    fontSize: '2.5rem',
    fontWeight: '800',
    color: '#ffffff',
    margin: '0 0 0.5rem 0',
    textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)'
  },
  statLabel: {
    fontSize: '1rem',
    color: 'rgba(255, 255, 255, 0.7)',
    margin: '0',
    fontWeight: '500'
  },
  logsSection: {
    marginTop: '2.5rem',
    width: '100%',
    background: 'rgba(255, 255, 255, 0.03)',
    borderRadius: '16px',
    padding: '2rem',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    backdropFilter: 'blur(10px)',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)'
  },
  sectionTitle: {
    fontSize: '1.5rem',
    fontWeight: '700',
    color: '#ffffff',
    margin: '0 0 2rem 0',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    textAlign: 'center'
  },
  logsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
    gap: '1.5rem',
    width: '100%'
  },
  logCard: {
    background: 'rgba(255, 255, 255, 0.05)',
    borderRadius: '12px',
    padding: '1.5rem',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(10px)',
    transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
    width: '100%',
    boxSizing: 'border-box',
    cursor: 'pointer',
    position: 'relative',
    overflow: 'hidden',
    '&:hover': {
      transform: 'translateY(-8px) scale(1.02)',
      boxShadow: '0 20px 40px rgba(0, 0, 0, 0.4)',
      borderColor: 'rgba(102, 126, 234, 0.5)'
    }
  },
  logHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '1rem',
    flexWrap: 'wrap',
    gap: '0.75rem'
  },
  logStatus: {
    color: 'white',
    padding: '0.5rem 1rem',
    borderRadius: '25px',
    fontSize: '0.8rem',
    fontWeight: '700',
    textTransform: 'uppercase',
    whiteSpace: 'nowrap',
    letterSpacing: '0.05em',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
  },
  logId: {
    fontSize: '0.8rem',
    color: 'rgba(255, 255, 255, 0.6)',
    fontFamily: 'monospace',
    whiteSpace: 'nowrap',
    fontWeight: '500'
  },
  logContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem'
  },
  logEmployee: {
    fontSize: '1rem',
    color: '#ffffff',
    margin: '0',
    fontWeight: '600'
  },
  logTime: {
    fontSize: '0.9rem',
    color: 'rgba(255, 255, 255, 0.7)',
    margin: '0',
    fontWeight: '500'
  },
  logSource: {
    fontSize: '0.9rem',
    color: 'rgba(255, 255, 255, 0.7)',
    margin: '0',
    fontWeight: '500'
  },
  emptyState: {
    textAlign: 'center',
    padding: '4rem 2rem',
    color: 'rgba(255, 255, 255, 0.7)',
    width: '100%'
  },
  emptyText: {
    fontSize: '1.25rem',
    margin: '0',
    fontWeight: '500'
  },
  viewMore: {
    textAlign: 'center',
    marginTop: '2rem',
    paddingTop: '2rem',
    borderTop: '1px solid rgba(255, 255, 255, 0.1)',
    width: '100%'
  },
  viewMoreText: {
    fontSize: '1rem',
    color: 'rgba(255, 255, 255, 0.7)',
    margin: '0',
    fontWeight: '500'
  },
  viewMoreButton: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    border: 'none',
    fontSize: '1rem',
    fontWeight: '700',
    cursor: 'pointer',
    marginLeft: '0.75rem',
    padding: '0.75rem 1.5rem',
    borderRadius: '25px',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    whiteSpace: 'nowrap',
    boxShadow: 'rgba(102, 126, 234, 0.3) 0px 4px 12px',
    '&:hover': {
      transform: 'translateY(-2px) scale(1.05)',
      boxShadow: 'rgba(102, 126, 234, 0.4) 0px 8px 20px',
      filter: 'brightness(1.1)'
    }
  },
  loading: {
    textAlign: 'center',
    padding: '4rem 2rem',
    color: 'rgba(255, 255, 255, 0.7)',
    width: '100%'
  },
  skeletonStatsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '1.5rem',
    marginBottom: '2.5rem',
    width: '100%'
  },
  skeletonStatCard: {
    background: 'rgba(255, 255, 255, 0.05)',
    borderRadius: '16px',
    padding: '2rem',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(10px)',
    display: 'flex',
    alignItems: 'center',
    gap: '1.5rem',
    width: '100%',
    boxSizing: 'border-box',
    transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
    cursor: 'pointer',
    position: 'relative',
    overflow: 'hidden'
  },
  skeletonStatIcon: {
    width: '60px',
    height: '60px',
    borderRadius: '16px',
    background: 'rgba(255, 255, 255, 0.1)',
    flexShrink: '0'
  },
  skeletonStatContent: {
    flex: '1',
    minWidth: '0'
  },
  skeletonStatNumber: {
    width: '80%',
    height: '2.5rem',
    background: 'rgba(255, 255, 255, 0.1)',
    borderRadius: '8px',
    marginBottom: '0.5rem'
  },
  skeletonStatLabel: {
    width: '60%',
    height: '1rem',
    background: 'rgba(255, 255, 255, 0.1)',
    borderRadius: '8px'
  },
  skeletonLogsSection: {
    marginTop: '2.5rem',
    width: '100%',
    background: 'rgba(255, 255, 255, 0.03)',
    borderRadius: '16px',
    padding: '2rem',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    backdropFilter: 'blur(10px)',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)'
  },
  skeletonLogsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
    gap: '1.5rem',
    width: '100%'
  },
  skeletonLogCard: {
    background: 'rgba(255, 255, 255, 0.05)',
    borderRadius: '12px',
    padding: '1.5rem',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(10px)',
    transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
    width: '100%',
    boxSizing: 'border-box',
    cursor: 'pointer',
    position: 'relative',
    overflow: 'hidden'
  },
  skeletonLogHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '1rem',
    flexWrap: 'wrap',
    gap: '0.75rem'
  },
  skeletonLogStatus: {
    width: '60px',
    height: '24px',
    borderRadius: '12px',
    background: 'rgba(255, 255, 255, 0.1)'
  },
  skeletonLogId: {
    width: '80px',
    height: '1rem',
    background: 'rgba(255, 255, 255, 0.1)',
    borderRadius: '4px'
  },
  skeletonLogContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem'
  },
  skeletonLogLine: {
    width: '100%',
    height: '1rem',
    background: 'rgba(255, 255, 255, 0.1)',
    borderRadius: '4px'
  },
  toast: {
    position: 'fixed',
    top: '20px',
    left: '50%',
    transform: 'translateX(-50%)',
    background: 'rgba(255, 255, 255, 0.95)',
    borderRadius: '12px',
    padding: '1rem 2rem',
    border: '1px solid rgba(255, 255, 255, 0.2)',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.4)',
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    zIndex: 9999,
    opacity: 0.95,
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    backdropFilter: 'blur(10px)',
    textAlign: 'center',
    fontSize: '1rem',
    fontWeight: '600',
    color: '#374151',
    animation: 'slideDown 0.3s ease-out',
    maxWidth: '500px'
  },
  toastSuccess: {
    borderLeft: '4px solid #10b981',
    color: '#10b981'
  },
  toastError: {
    borderLeft: '4px solid #ef4444',
    color: '#ef4444'
  },
  toastIcon: {
    fontSize: '1.25rem'
  },
  toastMessage: {
    fontSize: '0.9rem',
    fontWeight: '600',
    color: '#374151'
  },
  toastClose: {
    background: 'none',
    border: 'none',
    fontSize: '1.5rem',
    color: '#94a3b8',
    cursor: 'pointer',
    padding: '0.25rem',
    lineHeight: '1',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    '&:hover': {
      color: '#64748b',
      transform: 'scale(1.1)'
    }
  }
};
