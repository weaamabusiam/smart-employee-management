import React, { useState, useEffect } from 'react';
import AttendanceScreen from './screens/AttendanceScreen';
import LoginScreen from './screens/LoginScreen';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App() {
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Try to load token from storage on app start
    AsyncStorage.getItem('authToken').then(storedToken => {
      setToken(storedToken);
      setLoading(false);
    });
  }, []);

  const handleLogin = async (newToken) => {
    setToken(newToken);
    await AsyncStorage.setItem('authToken', newToken);
  };

  const handleLogout = () => {
    setToken(null);
    AsyncStorage.removeItem('authToken');
  };

  if (loading) return null;
  if (!token) return <LoginScreen onLogin={handleLogin} />;
  return <AttendanceScreen token={token} onLogout={handleLogout} />;
}
