import React, { useEffect, useState } from 'react';
import { View, Text, Button, StyleSheet, Alert, ScrollView, RefreshControl } from 'react-native';
import * as Notifications from 'expo-notifications';
import { fetchAttendance, getCurrentUser, logout } from '../services/ApiService';
import AttendanceStatus from '../components/AttendanceStatus';

// Configure notification behavior
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function AttendanceScreen({ token, onLogout }) {
  const [status, setStatus] = useState('Unknown');
  const [isPresent, setIsPresent] = useState(false);
  const [attendance, setAttendance] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [user, setUser] = useState(null);
  const [lastUpdate, setLastUpdate] = useState(null);

  useEffect(() => {
    initializeApp();
    setupNotifications();
    setupPolling();
  }, []);

  const initializeApp = async () => {
    try {
      // Load user info and attendance
      await loadUserInfo();
      await loadAttendance();
      
      // Show welcome message
      setTimeout(() => {
        Alert.alert(
          '🎉 Welcome!',
          'Your attendance app is ready! You\'ll receive notifications when you\'re automatically checked in/out by the ESP32 system.',
          [{ text: 'Got it!' }]
        );
      }, 1500);
    } catch (error) {
      console.error('Initialization error:', error);
      Alert.alert('Error', 'Failed to initialize app');
    }
  };

  const setupNotifications = async () => {
    try {
      // Request notification permissions
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== 'granted') {
        console.log('Notifications not available in Expo Go - using polling instead');
        return;
      }

      // Listen for notifications
      const subscription = Notifications.addNotificationReceivedListener(notification => {
        console.log('Notification received:', notification);
        // Refresh attendance data when notification is received
        loadAttendance();
      });

      return () => subscription.remove();
    } catch (error) {
      console.error('Notification setup error:', error);
    }
  };

  const setupPolling = () => {
    // Poll for updates every 10 seconds since Expo Go doesn't support push notifications
    const pollInterval = setInterval(() => {
      console.log('Polling for attendance updates...');
      loadAttendance();
    }, 10000); // 10 seconds

    // Cleanup on unmount
    return () => clearInterval(pollInterval);
  };

  const loadUserInfo = async () => {
    try {
      const userData = await getCurrentUser();
      setUser(userData);
    } catch (error) {
      console.error('Failed to load user info:', error);
      if (error.message.includes('Access denied')) {
        Alert.alert(
          'Access Denied',
          'This app is only for employees. Please contact your administrator if you believe this is an error.',
          [{ text: 'OK', onPress: () => onLogout() }]
        );
      }
    }
  };

  const loadAttendance = async () => {
    try {
      console.log('Loading attendance data...');
      const data = await fetchAttendance();
      console.log('Fetched attendance data:', data);
      setAttendance(data);
      setLastUpdate(new Date().toLocaleTimeString());
      
      // Determine current status based on latest attendance record
      if (data && data.length > 0) {
        const latestRecord = data[0]; // Assuming data is sorted by date descending
        const today = new Date().toISOString().split('T')[0];
        const recordDate = latestRecord.timestamp ? latestRecord.timestamp.split('T')[0] : null;
        
        console.log('Latest record:', latestRecord);
        console.log('Today:', today);
        console.log('Record date:', recordDate);
        
        // Check if the record is from today (UTC date comparison)
        if (recordDate === today) {
          const isPresentStatus = latestRecord.status === 'present';
          setStatus(isPresentStatus ? 'Present' : 'Absent');
          setIsPresent(isPresentStatus);
          console.log('Status set to:', isPresentStatus ? 'Present' : 'Absent');
        } else {
          setStatus('Unknown');
          setIsPresent(false);
          console.log('Status set to: Unknown (no record for today)');
        }
      } else {
        setStatus('Unknown');
        setIsPresent(false);
        console.log('Status set to: Unknown (no records)');
      }
    } catch (error) {
      console.error('Failed to load attendance:', error);
      setStatus('Unknown');
      setIsPresent(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadAttendance();
    setRefreshing(false);
  };

  const handleLogout = async () => {
    try {
      await logout();
      onLogout();
    } catch (error) {
      console.error('Logout error:', error);
      Alert.alert('Error', 'Failed to logout');
    }
  };

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      <View style={styles.content}>
        <View style={styles.headerContainer}>
          <Text style={styles.header}>📱 Employee Attendance</Text>
          <Button title="Logout" onPress={handleLogout} color="#ef4444" />
        </View>
        
        {/* User Info */}
        {user && (
          <View style={styles.userCard}>
            <Text style={styles.userTitle}>
              Welcome, {user.employee_name || user.username}!
            </Text>
            <Text style={styles.userRole}>Employee</Text>
            {user.employee_email && (
              <Text style={styles.userEmail}>{user.employee_email}</Text>
            )}
          </View>
        )}


        {/* Attendance Status */}
        <View style={styles.statusCard}>
          <Text style={styles.statusTitle}>Current Status</Text>
          <AttendanceStatus status={status} />
          <Text style={styles.statusSubtext}>
            {status === 'Present' ? 'You are currently checked in' : 
             status === 'Absent' ? 'You are currently checked out' : 
             'No attendance record for today'}
          </Text>
        </View>

        {/* ESP32 Info */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>🤖 ESP32 System</Text>
          <Text style={styles.infoText}>
            The ESP32 device at the office entrance will automatically detect when you arrive and leave, and log your attendance.
          </Text>
          <Text style={styles.infoSubtext}>
            App automatically checks for updates every 10 seconds.
          </Text>
          {lastUpdate && (
            <Text style={styles.updateTime}>
              Last updated: {lastUpdate}
            </Text>
          )}
        </View>

        {/* Attendance History */}
        <View style={styles.historyCard}>
          <Text style={styles.historyTitle}>Recent Attendance</Text>
          {attendance.length === 0 ? (
            <Text style={styles.noData}>No attendance records found</Text>
          ) : (
            attendance.slice(0, 10).map((record, index) => (
              <View key={index} style={styles.recordItem}>
                <View style={styles.recordLeft}>
                  <Text style={styles.recordStatus}>
                    {record.status === 'present' ? '✅' : '❌'} {record.status.toUpperCase()}
                  </Text>
                  <Text style={styles.recordSource}>
                    {record.source === 'esp32' ? '🤖 Auto' : '📱 Manual'}
                  </Text>
                </View>
                <Text style={styles.recordTime}>{formatDate(record.timestamp)}</Text>
              </View>
            ))
          )}
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc'
  },
  content: {
    padding: 20,
    paddingTop: 60 // Add top padding to avoid iPhone notch
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1e293b',
    flex: 1
  },
  userCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },
  userTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 4
  },
  userRole: {
    fontSize: 14,
    color: '#6b7280'
  },
  userEmail: {
    fontSize: 12,
    color: '#9ca3af',
    marginTop: 2
  },
  statusCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },
  statusTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
    color: '#374151'
  },
  statusText: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 4
  },
  statusSubtext: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 8
  },
  infoCard: {
    backgroundColor: '#f0f9ff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#3b82f6'
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
    color: '#1e40af'
  },
  infoText: {
    fontSize: 14,
    color: '#1e40af',
    marginBottom: 8,
    lineHeight: 20
  },
  infoSubtext: {
    fontSize: 12,
    color: '#3b82f6',
    fontStyle: 'italic'
  },
  updateTime: {
    fontSize: 10,
    color: '#6b7280',
    marginTop: 4,
    fontStyle: 'italic'
  },
  historyCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },
  historyTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
    color: '#374151'
  },
  recordItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb'
  },
  recordLeft: {
    flex: 1
  },
  recordStatus: {
    fontSize: 14,
    fontWeight: '500',
    color: '#374151',
    marginBottom: 2
  },
  recordSource: {
    fontSize: 12,
    color: '#6b7280'
  },
  recordTime: {
    fontSize: 12,
    color: '#6b7280'
  },
  noData: {
    textAlign: 'center',
    color: '#6b7280',
    fontStyle: 'italic',
    marginTop: 20
  }
});