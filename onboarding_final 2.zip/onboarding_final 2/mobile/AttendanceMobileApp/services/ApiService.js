import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = 'http://10.0.0.31:3001/api'; // Updated to use Mac's IP address

// Set up axios interceptor to include auth token
axios.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Fetch attendance logs for the current employee
export const fetchAttendance = async () => {
  try {
    const res = await axios.get(`${API_URL}/attendance/my-attendance`);
    return res.data;
  } catch (err) {
    throw new Error(err.response?.data?.error || 'Failed to fetch attendance');
  }
};

// Log attendance (check in/out)
export const logAttendance = async (status, source = 'mobile') => {
  try {
    // Get current user info to get employee ID
    const user = await getCurrentUser();
    console.log('User data for attendance:', user);
    
    if (!user.employee_id) {
      throw new Error('Employee ID not found. Please contact administrator.');
    }
    
    console.log('Logging attendance for employee_id:', user.employee_id, 'status:', status);
    
    const res = await axios.post(`${API_URL}/attendance`, {
      employee_id: user.employee_id,
      status,
      source
    });
    return res.data;
  } catch (err) {
    console.error('Attendance logging error:', err);
    throw new Error(err.response?.data?.error || err.message || 'Failed to log attendance');
  }
};

// Login function to authenticate with backend and store JWT token in AsyncStorage
export const login = async (username, password) => {
  try {
    const res = await axios.post(`${API_URL}/auth/login`, { username, password });
    const { token, user } = res.data;
    if (!token) throw new Error('No token received');
    
    // Check if user is an employee (role_id = 3)
    if (user.role_id !== 3) {
      throw new Error('Access denied. This app is only for employees.');
    }
    
    await AsyncStorage.setItem('authToken', token);
    await AsyncStorage.setItem('userInfo', JSON.stringify(user));
    return token;
  } catch (err) {
    throw new Error(err.response?.data?.error || err.message || 'Login failed');
  }
};

// Get current user info
export const getCurrentUser = async () => {
  try {
    // First try to get from storage
    const storedUser = await AsyncStorage.getItem('userInfo');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      console.log('Stored user data:', userData);
      return userData;
    }
    
    // Fallback to API call
    const res = await axios.get(`${API_URL}/auth/me`);
    const userData = res.data;
    console.log('API user data:', userData);
    await AsyncStorage.setItem('userInfo', JSON.stringify(userData));
    return userData;
  } catch (err) {
    console.error('Error getting user info:', err);
    throw new Error(err.response?.data?.error || 'Failed to get user info');
  }
};

// Logout function
export const logout = async () => {
  try {
    await AsyncStorage.removeItem('authToken');
    await AsyncStorage.removeItem('userInfo');
    return true;
  } catch (err) {
    throw new Error('Failed to logout');
  }
};
