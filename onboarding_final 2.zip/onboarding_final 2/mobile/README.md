# 📱 Mobile App - Employee Attendance System

A React Native mobile application that provides employees with attendance management capabilities through **manual check-in/out** and **Bluetooth status monitoring**. The app does NOT broadcast Bluetooth signals - it only displays Bluetooth status and allows manual attendance logging.

> **📚 [← Back to Main Documentation](../README.md)** | **[🖥️ Backend Server](../backend/README.md)** | **[📊 Dashboard](../dashboard/README.md)** | **[🔧 ESP32 Hardware](../esp32/README.md)**

## 🚀 Quick Start

### Prerequisites
- Node.js (v16 or higher)
- React Native CLI
- Android Studio (for Android development)
- Xcode (for iOS development)
- Backend server running (port 3000)

### Installation
```bash
# Install dependencies
npm install

# For iOS (macOS only)
cd ios && pod install && cd ..

# Start Metro bundler
npx react-native start

# Run on Android
npx react-native run-android

# Run on iOS
npx react-native run-ios
```

## 🏗️ Architecture

### Project Structure
```
mobile/
├── App.js                    # Main application component
├── screens/                  # App screens
│   ├── LoginScreen.js        # User authentication
│   └── AttendanceScreen.js   # Main attendance interface
├── components/               # Reusable components
│   └── AttendanceStatus.js   # Status display component
├── services/                 # API and Bluetooth services
│   ├── ApiService.js         # Backend API integration
│   └── BluetoothService.js   # BLE functionality
├── package.json
└── README.md
```

## ✨ Features

### 🔐 Authentication
- **Secure Login** - JWT-based authentication
- **Session Management** - Automatic token storage
- **Auto-logout** - Session timeout protection
- **User Profile** - Current user information

### 📡 Bluetooth Status
- **Status Monitoring** - Shows if Bluetooth is ON/OFF
- **Device MAC Display** - Shows device MAC address for reference
- **No Broadcasting** - App does NOT broadcast Bluetooth signals
- **ESP32 Detection** - ESP32 detects the device automatically
- **Status Updates** - Real-time Bluetooth status monitoring

### ⏰ Attendance Management
- **Smart Check-in/out** - Bluetooth-aware attendance logging with helpful prompts
- **Attendance History** - Personal attendance records with source tracking
- **Status Display** - Current attendance status
- **Source Tracking** - Shows if logged via ESP32 (auto) or mobile (manual)
- **Real-time Updates** - Live status synchronization
- **User Guidance** - Helpful tips and recommendations for optimal usage

### 📊 User Interface
- **Modern Design** - Clean, intuitive interface with emojis and friendly messaging
- **Status Cards** - Visual status indicators with helpful tips
- **Loading States** - Smooth loading animations
- **Error Handling** - User-friendly error messages
- **Responsive Layout** - Works on all screen sizes
- **Smart Alerts** - Context-aware notifications and recommendations

### 💡 User Guidance Features
- **Bluetooth Check** - Warns users to turn on Bluetooth before check-in
- **Checkout Tips** - Suggests turning off Bluetooth after checkout to save battery
- **Welcome Messages** - Helpful onboarding messages based on Bluetooth status
- **Visual Tips** - Inline tips and warnings for optimal usage
- **Smart Prompts** - Context-aware alerts and recommendations

## 🛠️ Tech Stack

- **Framework**: React Native
- **Language**: JavaScript
- **Bluetooth**: react-native-ble-plx
- **Storage**: @react-native-async-storage/async-storage
- **HTTP Client**: Axios
- **State Management**: React Hooks

## 📱 Screens

### Login Screen
- **Username/Password Input** - Secure authentication
- **Login Button** - JWT token generation
- **Error Handling** - Invalid credentials feedback
- **Loading States** - Login process indication

### Attendance Screen
- **Bluetooth Status** - BLE connection status
- **Device Information** - MAC address display
- **Manual Controls** - Check-in/out buttons
- **Attendance History** - Recent attendance records
- **Status Indicators** - Current presence status

## 🔧 Configuration

### API Configuration
Update `services/ApiService.js` with your backend URL:

```javascript
const API_URL = 'http://localhost:3000/api';
```

### Bluetooth Configuration
Configure BLE settings in `services/BluetoothService.js`:

```javascript
// Service UUIDs
const serviceUUID = '12345678-1234-1234-1234-123456789ABC';
const characteristicUUID = '87654321-4321-4321-4321-CBA987654321';
```

### Environment Variables
Create `.env` file for configuration:

```env
API_URL=http://localhost:3000/api
BLE_SERVICE_UUID=12345678-1234-1234-1234-123456789ABC
BLE_CHARACTERISTIC_UUID=87654321-4321-4321-4321-CBA987654321
```

## 📡 Bluetooth Integration

### BLE Advertising
The app advertises as a BLE peripheral for ESP32 detection:

```javascript
// Start advertising
await startAdvertising('EMP001');

// Stop advertising
await stopAdvertising();
```

### Device Detection
ESP32 devices are automatically detected and logged:

```javascript
// Scan for ESP32 devices
scanForESP32((device) => {
  console.log('ESP32 detected:', device);
});
```

### MAC Address Management
Device MAC addresses are used for identification:

```javascript
// Get device MAC address
const macAddress = await getDeviceMacAddress();
```

## 🔐 Authentication Flow

### Login Process
1. **User Input** - Username and password
2. **API Call** - Send credentials to backend
3. **Token Storage** - Store JWT token locally
4. **Session Management** - Set up authenticated session
5. **Navigation** - Redirect to attendance screen

### Session Management
- **Token Storage** - AsyncStorage for persistence
- **Auto-refresh** - Automatic token renewal
- **Logout** - Clear stored tokens
- **Error Handling** - Invalid token handling

## 📊 Data Management

### API Integration
- **Authentication** - Login and user management
- **Attendance Logging** - Check-in/out operations
- **Data Fetching** - Attendance history retrieval
- **Error Handling** - Network error management

### Local Storage
- **JWT Tokens** - Secure token storage
- **User Data** - Current user information
- **Settings** - App configuration
- **Cache** - Offline data caching

## 🎨 User Interface

### Design Principles
- **Simplicity** - Clean, uncluttered interface
- **Accessibility** - Easy to use for all users
- **Consistency** - Uniform design patterns
- **Feedback** - Clear user feedback

### Components
- **Status Cards** - Visual status indicators
- **Buttons** - Touch-friendly controls
- **Input Fields** - Form input components
- **Loading Indicators** - Process feedback
- **Error Messages** - User-friendly errors

### Color Scheme
- **Primary**: Blue (#4f46e5)
- **Success**: Green (#10b981)
- **Error**: Red (#ef4444)
- **Warning**: Yellow (#f59e0b)
- **Background**: Light Gray (#f8fafc)

## 🧪 Testing

### Available Scripts
```bash
# Start Metro bundler
npm start

# Run on Android
npm run android

# Run on iOS
npm run ios

# Run tests
npm test

# Run linting
npm run lint
```

### Testing Features
- **Unit Tests** - Component and service tests
- **Integration Tests** - API integration tests
- **E2E Tests** - Full user flow tests
- **Bluetooth Tests** - BLE functionality tests

## 📱 Platform Support

### Android
- **Minimum SDK**: 21 (Android 5.0)
- **Target SDK**: 33 (Android 13)
- **Permissions**: Bluetooth, Internet, Storage
- **Features**: Full BLE support

### iOS
- **Minimum Version**: iOS 11.0
- **Target Version**: iOS 16.0
- **Permissions**: Bluetooth, Internet
- **Features**: Full BLE support

## 🔧 Development

### Debugging
```bash
# Enable debug mode
npx react-native start --reset-cache

# Debug on Android
npx react-native run-android --variant=debug

# Debug on iOS
npx react-native run-ios --configuration=Debug
```

### Hot Reloading
- **Fast Refresh** - Instant code updates
- **Live Reloading** - Full app reload
- **Error Overlay** - Development error display
- **Performance Monitor** - Real-time performance metrics

## 🚀 Build & Deployment

### Development Build
```bash
# Android debug build
npx react-native run-android --variant=debug

# iOS debug build
npx react-native run-ios --configuration=Debug
```

### Production Build
```bash
# Android release build
cd android && ./gradlew assembleRelease

# iOS release build
npx react-native run-ios --configuration=Release
```

### App Store Deployment
1. **Build Configuration** - Set up release builds
2. **Code Signing** - Configure certificates
3. **App Store Connect** - Upload to store
4. **Testing** - TestFlight beta testing
5. **Release** - App store release

## 🔐 Security Features

### Data Protection
- **JWT Tokens** - Secure authentication
- **Local Storage** - Encrypted data storage
- **Network Security** - HTTPS communication
- **Input Validation** - Secure input handling

### Bluetooth Security
- **Device Verification** - Trusted device detection
- **Data Encryption** - Secure BLE communication
- **Access Control** - Permission-based access
- **Error Handling** - Secure error management

## 📊 Performance Optimization

### Loading Performance
- **Lazy Loading** - Component lazy loading
- **Image Optimization** - Optimized images
- **Bundle Splitting** - Code splitting
- **Caching** - Data caching strategies

### Memory Management
- **Component Cleanup** - Proper cleanup
- **Memory Leaks** - Leak prevention
- **State Management** - Efficient state updates
- **Resource Management** - Resource cleanup

## 🐛 Troubleshooting

### Common Issues

#### Metro Bundler Issues
```bash
# Clear cache
npx react-native start --reset-cache

# Clear node modules
rm -rf node_modules && npm install
```

#### Android Build Issues
```bash
# Clean Android build
cd android && ./gradlew clean

# Rebuild
npx react-native run-android
```

#### iOS Build Issues
```bash
# Clean iOS build
cd ios && xcodebuild clean

# Rebuild
npx react-native run-ios
```

#### Bluetooth Issues
```bash
# Check Bluetooth permissions
# Android: Settings > Apps > Permissions
# iOS: Settings > Privacy > Bluetooth
```

### Debug Tools
- **React Native Debugger** - Advanced debugging
- **Flipper** - Mobile development platform
- **Chrome DevTools** - Web debugging
- **Xcode/Android Studio** - Native debugging

## 📚 API Documentation

### Authentication Endpoints
```javascript
// Login
POST /api/auth/login
{
  "username": "employee",
  "password": "password123"
}

// Get current user
GET /api/auth/me
Authorization: Bearer <token>
```

### Attendance Endpoints
```javascript
// Log attendance
POST /api/attendance
{
  "employee_id": "EMP001",
  "status": "present",
  "source": "mobile"
}

// Get attendance history
GET /api/attendance
Authorization: Bearer <token>
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure cross-platform compatibility
6. Submit a pull request

## 📝 License

This project is part of the Employee Attendance System and is licensed under the MIT License.

---

**Mobile App - Employee Attendance Management on the Go** 📱
