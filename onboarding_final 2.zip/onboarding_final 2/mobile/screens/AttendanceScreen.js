import React, { useEffect, useState } from 'react';
import { View, Text, Button, StyleSheet, Alert, ScrollView, RefreshControl } from 'react-native';
import { 
  checkBluetoothStatus, 
  getDeviceMacAddress,
  monitorBluetoothState
} from '../services/BluetoothService';
import { fetchAttendance, logAttendance, getCurrentUser, logout } from '../services/ApiService';
import AttendanceStatus from '../components/AttendanceStatus';

export default function AttendanceScreen({ token, onLogout }) {
  const [status, setStatus] = useState('Unknown');
  const [isPresent, setIsPresent] = useState(false);
  const [attendance, setAttendance] = useState([]);
  const [bluetoothEnabled, setBluetoothEnabled] = useState(false);
  const [deviceMac, setDeviceMac] = useState(null);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    initializeApp();
    
    // Monitor Bluetooth state changes
    const subscription = monitorBluetoothState((isEnabled) => {
      setBluetoothEnabled(isEnabled);
    });
    
    return () => {
      subscription.remove();
    };
  }, []);

  const initializeApp = async () => {
    try {
      setLoading(true);
      
      // Check Bluetooth status
      const bluetoothReady = await checkBluetoothStatus();
      setBluetoothEnabled(bluetoothReady);
      
      // Get device MAC address for display
      const mac = await getDeviceMacAddress();
      setDeviceMac(mac);
      
      // Load user info and attendance
      await loadUserInfo();
      await loadAttendance();
      
      // Show helpful message based on Bluetooth status
      setTimeout(() => {
        if (!bluetoothReady) {
          Alert.alert(
            '🔵 Bluetooth Status',
            'Bluetooth is currently OFF. Turn it ON to enable automatic attendance detection by ESP32, or use manual check-in/out.',
            [{ text: 'Got it!' }]
          );
        } else {
          Alert.alert(
            '🎉 Welcome!',
            'Your app is ready! Bluetooth is ON, so ESP32 can automatically detect your presence. You can also use manual check-in/out anytime.',
            [{ text: 'Let\'s go!' }]
          );
        }
      }, 1500);
    } catch (error) {
      console.error('Initialization error:', error);
      Alert.alert('Error', 'Failed to initialize app');
    } finally {
      setLoading(false);
    }
  };

  const loadUserInfo = async () => {
    try {
      const userData = await getCurrentUser();
      setUser(userData);
    } catch (error) {
      console.error('Failed to load user info:', error);
      if (error.message.includes('Access denied')) {
        Alert.alert(
          'Access Denied',
          'This app is only for employees. Please contact your administrator if you believe this is an error.',
          [{ text: 'OK', onPress: () => onLogout() }]
        );
      }
    }
  };

  const loadAttendance = async () => {
    try {
      const data = await fetchAttendance();
      setAttendance(data);
    } catch (error) {
      console.error('Failed to load attendance:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadAttendance();
    setRefreshing(false);
  };

  const handleCheckIn = async () => {
    // Check if Bluetooth is enabled before check-in
    if (!bluetoothEnabled) {
      Alert.alert(
        'Bluetooth Required',
        'Please turn on Bluetooth to enable automatic attendance detection by ESP32. You can still check in manually, but automatic detection won\'t work.',
        [
          {
            text: 'Check In Anyway',
            onPress: () => performCheckIn()
          },
          {
            text: 'Turn On Bluetooth',
            style: 'cancel'
          }
        ]
      );
      return;
    }
    
    await performCheckIn();
  };

  const performCheckIn = async () => {
    try {
      setLoading(true);
      await logAttendance('present', 'mobile');
      setStatus('Present');
      setIsPresent(true);
      await loadAttendance();
      Alert.alert(
        '✅ Checked In Successfully!',
        'Welcome to work! Your attendance has been logged.',
        [{ text: 'OK' }]
      );
    } catch (error) {
      console.error('Check-in error:', error);
      Alert.alert('Error', 'Failed to check in');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckOut = async () => {
    try {
      setLoading(true);
      await logAttendance('absent', 'mobile');
      setStatus('Absent');
      setIsPresent(false);
      await loadAttendance();
      
      // Sweet recommendation to turn off Bluetooth after checkout
      Alert.alert(
        '👋 Checked Out Successfully!',
        'Have a great day! 💙\n\n💡 Tip: You can now turn off Bluetooth to save battery, since you\'re no longer in the office.',
        [
          {
            text: 'Thanks!',
            style: 'default'
          }
        ]
      );
    } catch (error) {
      console.error('Check-out error:', error);
      Alert.alert('Error', 'Failed to check out');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      onLogout();
    } catch (error) {
      console.error('Logout error:', error);
      Alert.alert('Error', 'Failed to logout');
    }
  };

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      <View style={styles.content}>
        <View style={styles.headerContainer}>
          <Text style={styles.header}>📱 Employee Attendance</Text>
          <Button title="Logout" onPress={handleLogout} color="#ef4444" />
        </View>
        
        {/* User Info */}
        {user && (
          <View style={styles.userCard}>
            <Text style={styles.userTitle}>
              Welcome, {user.employee_name || user.username}!
            </Text>
            <Text style={styles.userRole}>Employee</Text>
            {user.employee_email && (
              <Text style={styles.userEmail}>{user.employee_email}</Text>
            )}
          </View>
        )}

        {/* Bluetooth Status */}
        <View style={styles.statusCard}>
          <Text style={styles.statusTitle}>🔵 Bluetooth Status</Text>
          <Text style={[styles.statusText, { color: bluetoothEnabled ? '#10b981' : '#ef4444' }]}>
            {bluetoothEnabled ? '✅ Bluetooth ON' : '❌ Bluetooth OFF'}
          </Text>
          <Text style={styles.statusSubtext}>
            {bluetoothEnabled 
              ? '🎯 ESP32 can detect your device for automatic attendance' 
              : '⚠️ Turn on Bluetooth to enable automatic detection'
            }
          </Text>
          {deviceMac && (
            <Text style={styles.macText}>Device MAC: {deviceMac}</Text>
          )}
          {!bluetoothEnabled && (
            <View style={styles.tipContainer}>
              <Text style={styles.tipText}>
                💡 Tip: Keep Bluetooth ON while at work for automatic check-in/out
              </Text>
            </View>
          )}
        </View>

        {/* Attendance Status */}
        <View style={styles.statusCard}>
          <Text style={styles.statusTitle}>Current Status</Text>
          <AttendanceStatus status={status} />
        </View>

        {/* Manual Controls */}
        <View style={styles.controlsCard}>
          <Text style={styles.controlsTitle}>📱 Manual Check-in/out</Text>
          <Text style={styles.controlsSubtext}>
            {bluetoothEnabled 
              ? 'Use this as backup when automatic detection fails'
              : 'Use this when Bluetooth is off or automatic detection is unavailable'
            }
          </Text>
          <View style={styles.buttonContainer}>
            <Button
              title={isPresent ? "🚪 Check Out" : "🚪 Check In"}
              onPress={isPresent ? handleCheckOut : handleCheckIn}
              disabled={loading}
              color={isPresent ? "#ef4444" : "#10b981"}
            />
          </View>
          {!bluetoothEnabled && (
            <Text style={styles.warningText}>
              ⚠️ Manual check-in/out only. Turn on Bluetooth for automatic detection.
            </Text>
          )}
        </View>

        {/* Attendance History */}
        <View style={styles.historyCard}>
          <Text style={styles.historyTitle}>Recent Attendance</Text>
          {attendance.length === 0 ? (
            <Text style={styles.noData}>No attendance records found</Text>
          ) : (
            attendance.slice(0, 10).map((record, index) => (
              <View key={index} style={styles.recordItem}>
                <View style={styles.recordLeft}>
                  <Text style={styles.recordStatus}>
                    {record.status === 'present' ? '✅' : '❌'} {record.status.toUpperCase()}
                  </Text>
                  <Text style={styles.recordSource}>
                    {record.source === 'esp32' ? '🤖 Auto' : '📱 Manual'}
                  </Text>
                </View>
                <Text style={styles.recordTime}>{formatDate(record.timestamp)}</Text>
              </View>
            ))
          )}
        </View>

        {loading && (
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading...</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc'
  },
  content: {
    padding: 20
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1e293b',
    flex: 1
  },
  userCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },
  userTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 4
  },
  userRole: {
    fontSize: 14,
    color: '#6b7280'
  },
  userEmail: {
    fontSize: 12,
    color: '#9ca3af',
    marginTop: 2
  },
  statusCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },
  statusTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
    color: '#374151'
  },
  statusText: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 4
  },
  statusSubtext: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 8
  },
  macText: {
    fontSize: 12,
    color: '#6b7280',
    fontFamily: 'monospace'
  },
  tipContainer: {
    backgroundColor: '#fef3c7',
    padding: 12,
    borderRadius: 8,
    marginTop: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#f59e0b'
  },
  tipText: {
    fontSize: 12,
    color: '#92400e',
    fontStyle: 'italic'
  },
  controlsCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },
  controlsTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
    color: '#374151'
  },
  controlsSubtext: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 12
  },
  buttonContainer: {
    marginTop: 8
  },
  warningText: {
    fontSize: 12,
    color: '#dc2626',
    textAlign: 'center',
    marginTop: 8,
    fontStyle: 'italic'
  },
  historyCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3
  },
  historyTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
    color: '#374151'
  },
  recordItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb'
  },
  recordLeft: {
    flex: 1
  },
  recordStatus: {
    fontSize: 14,
    fontWeight: '500',
    color: '#374151',
    marginBottom: 2
  },
  recordSource: {
    fontSize: 12,
    color: '#6b7280'
  },
  recordTime: {
    fontSize: 12,
    color: '#6b7280'
  },
  noData: {
    textAlign: 'center',
    color: '#6b7280',
    fontStyle: 'italic',
    marginTop: 20
  },
  loadingContainer: {
    alignItems: 'center',
    marginTop: 20
  },
  loadingText: {
    color: '#6b7280',
    fontSize: 16
  }
});
