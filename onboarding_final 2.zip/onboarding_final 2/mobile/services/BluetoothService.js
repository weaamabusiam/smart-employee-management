import { BleManager, State } from 'react-native-ble-plx';

const manager = new BleManager();

// Check if Bluetooth is enabled (ON/OFF only)
export const checkBluetoothStatus = async () => {
  try {
    const state = await manager.state();
    return state === State.PoweredOn;
  } catch (error) {
    console.error('Bluetooth status check error:', error);
    return false;
  }
};

// Get device MAC address for display purposes only
export const getDeviceMacAddress = async () => {
  try {
    // In a real implementation, you'd get the actual MAC address
    // For now, we'll generate a mock MAC address for display
    const mockMac = 'AA:BB:CC:DD:EE:FF';
    return mockMac;
  } catch (error) {
    console.error('Failed to get MAC address:', error);
    return null;
  }
};

// Monitor Bluetooth state changes
export const monitorBluetoothState = (callback) => {
  const subscription = manager.onStateChange((state) => {
    callback(state === State.PoweredOn);
  }, true);
  
  return subscription;
};

