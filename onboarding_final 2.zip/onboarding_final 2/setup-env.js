#!/usr/bin/env node

/**
 * Environment Setup Script for Attendance System
 * This script helps you set up environment variables for all components
 */

const fs = require('fs');
const path = require('path');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const question = (query) => new Promise((resolve) => rl.question(query, resolve));

const configs = {
  backend: {
    file: 'backend/.env',
    template: `# Backend Environment Variables
NODE_ENV=development
PORT=3001
HOST=localhost

# Database Configuration
DB_HOST=localhost
DB_PORT=3306
DB_NAME=attendance_system
DB_USER=root
DB_PASSWORD={DB_PASSWORD}
DB_DIALECT=mysql

# JWT Configuration
JWT_SECRET={JWT_SECRET}
JWT_EXPIRES_IN=24h
JWT_REFRESH_EXPIRES_IN=7d

# CORS Configuration
CORS_ORIGIN=http://localhost:3000,http://localhost:5173

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# Security
SESSION_SECRET={SESSION_SECRET}
SESSION_COOKIE_MAX_AGE=86400000

# Logging
LOG_LEVEL=info
LOG_FILE=logs/app.log
LOG_MAX_SIZE=10m
LOG_MAX_FILES=5

# Development
DEBUG=true
VERBOSE_LOGGING=true`
  },
  dashboard: {
    file: 'dashboard/.env',
    template: `# Dashboard Environment Variables
VITE_API_BASE_URL=http://localhost:3001/api
VITE_APP_TITLE=Attendance Management System
VITE_APP_VERSION=1.0.0
VITE_DEBUG=true`
  },
  mobile: {
    file: 'mobile/.env',
    template: `# Mobile App Environment Variables
REACT_NATIVE_API_BASE_URL=http://localhost:3001/api
REACT_NATIVE_APP_NAME=Attendance Mobile
BLUETOOTH_SCAN_DURATION=10000
BLUETOOTH_CONNECTION_TIMEOUT=5000`
  }
};

async function generateRandomString(length = 32) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

async function setupEnvironment() {
  console.log('🚀 Setting up environment variables for Attendance System\n');

  try {
    // Get database password
    const dbPassword = await question('Enter MySQL root password: ');
    
    // Generate secrets
    const jwtSecret = await generateRandomString(64);
    const sessionSecret = await generateRandomString(32);

    console.log('\n📝 Creating environment files...\n');

    // Create backend .env
    const backendEnv = configs.backend.template
      .replace('{DB_PASSWORD}', dbPassword)
      .replace('{JWT_SECRET}', jwtSecret)
      .replace('{SESSION_SECRET}', sessionSecret);

    fs.writeFileSync(configs.backend.file, backendEnv);
    console.log(`✅ Created ${configs.backend.file}`);

    // Create dashboard .env
    fs.writeFileSync(configs.dashboard.file, configs.dashboard.template);
    console.log(`✅ Created ${configs.dashboard.file}`);

    // Create mobile .env
    fs.writeFileSync(configs.mobile.file, configs.mobile.template);
    console.log(`✅ Created ${configs.mobile.file}`);

    console.log('\n🎉 Environment setup complete!');
    console.log('\n📋 Next steps:');
    console.log('1. Start MySQL server');
    console.log('2. Import database schema: mysql -u root -p attendance_system < schema.sql');
    console.log('3. Install dependencies: npm install (in each directory)');
    console.log('4. Start the backend: cd backend && npm start');
    console.log('5. Start the dashboard: cd dashboard && npm run dev');

  } catch (error) {
    console.error('❌ Error setting up environment:', error.message);
  } finally {
    rl.close();
  }
}

// Run the setup
setupEnvironment();
